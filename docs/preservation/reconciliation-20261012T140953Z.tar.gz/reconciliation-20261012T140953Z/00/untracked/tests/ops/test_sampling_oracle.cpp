// CPU-only independent FP64 numerical oracle for the public `sample()` contract
// (Issue 45). The oracle reimplements the complete documented sampling semantics
// in pure FP64 on a small-vocabulary fixture set - no production code, no CUDA
// headers, no production RNG, no other production path is used as the golden.
//
// Discriminator fixtures (a mismatch in any rule below is the exact failure this
// test detects):
//   (A) presence/frequency penalties are SUBTRACTED FROM THE LOGIT BEFORE the
//       candidate sort; penalties and min-p/top-p filter order is
//       penalty -> sort -> top-k -> weights -> min-p -> top-p -> renormalize.
//   (B) top_p < 1 keeps the shortest prefix whose cumulative weight reaches the
//       top_p * total target; top_p >= 1 (and top_k <= 0) disables the filter.
//   (C) top_k > the pipeline cap (20) and top_k > token_domain clamp to
//       min(20, token_domain); top_k <= 0 keeps min(20, token_domain).
//   (D) min_p threshold is min_p * max_candidate_weight (weight scale), not
//       min_p * max_probability (probability scale): the same min_p drops the
//       last candidate at temperature 1.0 but keeps it at 1.05.
//   (E) temperature <= 0: pure greedy argmax over the RAW logits (penalties,
//       filters, RNG, token_counts updates all skipped); exact +0.0f/-0.0f tie
//       resolves to the lower token id, and -0.0f alone still picks a token.
//   (F) the counter-based RNG draw is a pure function of (seed, logical
//       position, purpose, sub) via splitmix64 - identical draws on identical
//       keys, and distinct when exactly one key field changes.
//   (G) the selected token atomically increments token_counts (only for
//       positive-temperature rows) and the increment must equal the drawn id.
//
// The docs/ISSUE45_SAMPLING_NUMERICAL_ORACLE.md page carries the full source
// map and per-fixture numerics.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

namespace {

// Reproduce tests/ops/op_tester.h::f32_to_bf16 exactly (the value the device
// kernel will read after round_to_bf16); kept here so the oracle stays pure-CPU.
std::uint16_t f32_to_bf16(float f) {
    std::uint32_t u;
    std::memcpy(&u, &f, 4);
    if ((u & 0x7fffffffu) > 0x7f800000u) { return std::uint16_t((u >> 16) | 0x0040u); }
    const std::uint32_t lsb = (u >> 16) & 1u;
    u += 0x7fffu + lsb;
    return std::uint16_t(u >> 16);
}

double bf16_to_f32(std::uint16_t b) {
    std::uint32_t u = std::uint32_t(b) << 16;
    float f;
    std::memcpy(&f, &u, 4);
    return f;
}

double round_to_bf16(double x) { return bf16_to_f32(f32_to_bf16(static_cast<float>(x))); }

// SamplingConfig field set (device struct, all fields used by the contract):
// temperature, top_k, top_p, min_p, presence_penalty, frequency_penalty,
// seed, token_counts (device pointer; the oracle models the host-side view).
struct Cfg {
    double temperature     = 0.0;
    int top_k              = 0;
    double top_p           = 1.0;
    double min_p           = 0.0;
    double presence_penalty  = 0.0;
    double frequency_penalty = 0.0;
    unsigned long long seed = 0;
    const std::vector<int>* counts = nullptr;
};

// Exact splitmix64 chain per sampling_device.cuh::sampling_uniform(seed, position,
// purpose, sub): two rounds; sub=0 contributes nothing. Pure (seed,position,purpose).
unsigned long long splitmix64(unsigned long long x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

// u in [0,1): 24-bit top of the second splitmix64 output.
double oracle_uniform(unsigned long long seed, int position, int purpose, unsigned int sub) {
    unsigned long long key = seed;
    key = splitmix64(key ^ (static_cast<unsigned long long>(position & 0xFFFFFFFFu) *
                            0xD1B54A32D192ED03ULL));
    key = splitmix64(key ^ (static_cast<unsigned long long>(purpose) << 21) ^
                     (static_cast<unsigned long long>(sub) * 0x2545F4914F6CDD1DULL));
    const unsigned int bits = static_cast<unsigned int>(key >> 40);
    return static_cast<double>(bits) / 16777216.0;
}

// FP64 reference of the stochastic branch: returns (picked token, support tokens
// ascending-adjusted descending, support size, drawn u) for one column.
struct Draw {
    int picked             = -1;
    std::vector<int> support;
    std::vector<double> weights;
    double u               = 0.0;
    int support_size       = 0;
};

Draw draw(const std::vector<double>& adjusted, const Cfg& cfg, int token_domain, double u) {
    Draw d;
    d.u = u;
    // Sort by adjusted value descending, lower token id breaking ties. (Token id is
    // the index into `adjusted`, mirroring the device key's (value, id) ordering.)
    std::vector<std::size_t> idx(adjusted.size());
    for (std::size_t i = 0; i < idx.size(); ++i) { idx[i] = i; }
    std::sort(idx.begin(), idx.end(), [&](std::size_t a, std::size_t b) {
        if (adjusted[a] != adjusted[b]) { return adjusted[a] > adjusted[b]; }
        return a < b;
    });
    int cap = 20;
    if (cfg.top_k > 0 && cfg.top_k < 20) { cap = cfg.top_k; }
    if (token_domain < cap) { cap = token_domain; }
    const std::size_t keep = static_cast<std::size_t>(cap);

    std::vector<double> w(keep);
    const double m = adjusted[idx.front()] / cfg.temperature;
    double total   = 0.0;
    for (std::size_t i = 0; i < keep; ++i) {
        w[i] = std::exp(adjusted[idx[i]] / cfg.temperature - m);
        total += w[i];
    }
    const double minp  = (cfg.min_p > 0.0) ? static_cast<double>(cfg.min_p) * w[0] : -1.0;
    const double topp  = (cfg.top_p < 1.0) ? static_cast<double>(cfg.top_p) * total : 0.0;
    const bool top_on  = cfg.top_p < 1.0;
    double cum          = 0.0;
    int support         = 0;
    for (std::size_t i = 0; i < keep; ++i) {
        if (minp >= 0.0 && w[i] < minp) { break; }
        cum += w[i];
        support = static_cast<int>(i) + 1;
        if (top_on && cum >= topp) { break; }
    }
    if (support < 1) { support = 1; }
    for (int j = 0; j < support; ++j) {
        d.support.push_back(static_cast<int>(idx[static_cast<std::size_t>(j)]));
        d.weights.push_back(w[static_cast<std::size_t>(j)]);
    }
    // Inverse-CDF over the weights: the device renormalizes the support before the
    // draw, so the draw is the first j with u < cumsum(w[0..j]) / total (the
    // normalization factor cancels against u in [0,1)).
    {
        double acc = 0.0;
        int picked_i = support - 1;
        for (int j = 0; j < support; ++j) {
            acc += w[static_cast<std::size_t>(j)];
            if (u * total < acc) { picked_i = j; break; }
        }
        d.picked = d.support.empty() ? -1 : d.support[static_cast<std::size_t>(picked_i)];
    }
    d.support_size = support;
    return d;
}

int check(const std::string& label, bool ok, const std::string& detail = "") {
    if (!ok) {
        std::cerr << "FAIL " << label << (detail.empty() ? "" : " [" + detail + "]") << "\n";
    }
    return ok ? 0 : 1;
}

// (A) Duplicate-penalty discriminators: the SAME row shape under three penalty
// regimes produces three DIFFERENT draws; any pipeline that applies penalties
// after sorting, or to probabilities instead of logits, changes exactly one.
int discriminator_penalties() {
    std::vector<double> raw = {3.0, 1.0, 1.0, 0.0, -1.0};
    std::vector<double> a;
    for (double x : raw) { a.push_back(round_to_bf16(x)); }
    const std::vector<int> counts = {0, 2, 1, 0, 0};  // token1 seen twice, token2 once
    int failures = 0;

    // A1: presence=1.0: tokens 1,2 adjusted 1-1=0, 1-1=0; token0 stays 3.0.
    // With top_p=0.8 the cumulative weight of token 0 alone (1.0 >= 0.8*total)
    // ends the prefix -> support {0} only; the penalized tokens never enter a
    // positive-temperature support.
    Cfg pc;
    pc.temperature = 1.0;
    pc.top_p             = 0.8;
    pc.presence_penalty  = 1.0;
    pc.counts            = &counts;
    std::vector<double> adj(a.size());
    for (std::size_t i = 0; i < a.size(); ++i) {
        double x = a[i];
        if (counts[i] > 0) { x -= pc.presence_penalty; }
        adj[i] = x;
    }
    double u = oracle_uniform(pc.seed, 11, 1, 0u);  // seed 0 -> deterministic chain
    const Draw d1 = draw(adj, pc, 5, u);
    failures += check("A1 presence: support excludes penalized top", d1.support.size() == 1 &&
                          d1.support.front() == 0,
                      "A1 presence penalty support");
    failures += check("A1 presence: draw is token 0", d1.picked == 0, "A1 presence pick");

    // A2: frequency=0.5: token1 -> 1-1.0=0.0, token2 -> 1-0.5=0.5.
    // Adjusted order {3:0, 0.5:2, 0.0:1, 0.0:3, -1:4}: token 2 (adj 0.5)
    // outranks token 0 (adj 0.0); the 0.0 tie resolves to the lower id (1
    // before 3). With top_p=0.95 the cumulative weight reaches 0.95*total
    // after token 1 -> support {0, 2, 1} (the 0.0 tie keeps ids 1, 3 out).
    Cfg fc;
    fc.temperature        = 1.0;
    fc.top_p              = 0.95;
    fc.frequency_penalty  = 0.5;
    fc.counts             = &counts;
    std::vector<double> adjf(a.size());
    for (std::size_t i = 0; i < a.size(); ++i) {
        double x = a[i];
        x -= fc.frequency_penalty * static_cast<double>(counts[i]);
        adjf[i] = x;
    }
    double uf = oracle_uniform(fc.seed, 11, 1, 0u);
    const Draw d2 = draw(adjf, fc, 5, uf);
    failures += check("A2 frequency: token 2 ranks above token 0 tie", d2.support.size() == 3 &&
                          d2.support[0] == 0 && d2.support[1] == 2 && d2.support[2] == 1,
                      "A2 frequency support order");

    // A3: no penalty + top_p=0.9: weights {exp(3), exp(1), exp(1), exp(0),
    // exp(-1)}; cumulative 0.9*total is first reached after token 2 ->
    // support {0,1,2}; the 1.0 tie (tokens 1, 2) resolves to the lower id first.
    Cfg nc;
    nc.temperature = 1.0;
    nc.top_p       = 0.9;
    double un = oracle_uniform(nc.seed, 11, 1, 0u);
    const Draw d3 = draw(a, nc, 5, un);
    failures += check("A3 no-penalty: raw order preserved", d3.support.size() == 3 &&
                          d3.support[0] == 0 && d3.support[1] == 1 && d3.support[2] == 2,
                      "A3 raw order (tie -> lower id)");
    if (d1.support == d2.support || d1.support == d3.support || d2.support == d3.support) {
        std::cerr << "A: penalty discriminators produced identical supports\n";
        ++failures;
    }
    return failures;
}

// (B) Filter-order discriminator: top_p (shortest prefix) and min_p (suffix cut)
// produce different supports; a pipeline that evaluates them in the wrong order,
// or as a join instead of a sequential break, changes exactly one.
int discriminator_filter_order() {
    std::vector<double> a = {round_to_bf16(3.0), round_to_bf16(2.0), round_to_bf16(1.0),
                             round_to_bf16(0.0), round_to_bf16(-2.0)};
    int failures = 0;

    // B1: top_p=0.90 only (min_p=0). Weights exp(logit-max) over the BF16-
    // rounded column {1, 0.3679, 0.1353, 0.04979, 0.00674}; the cumulative
    // weight first reaches 0.90*total after tokens {0,1} -> support {0,1}.
    Cfg tc;
    tc.temperature = 1.0;
    tc.top_p       = 0.90;
    double ut = oracle_uniform(tc.seed, 21, 1, 0u);
    const Draw dt = draw(a, tc, 5, ut);
    failures += check("B1 top-p only: shortest prefix {0,1}", dt.support.size() == 2 &&
                          dt.support[0] == 0 && dt.support[1] == 1,
                      "B1 top-p prefix");

    // B2: min_p=0.05 only (top_p=1.0): the min_p*max_WEIGHT threshold 0.05 is
    // just above the token 2 weight (0.049787) -> suffix cut keeps {0,1,2}.
    Cfg mc;
    mc.temperature = 1.0;
    mc.min_p       = 0.05;
    double um = oracle_uniform(mc.seed, 21, 1, 0u);
    const Draw dm = draw(a, mc, 5, um);
    failures += check("B2 min-p only: suffix cut keeps {0,1,2}", dm.support.size() == 3 &&
                          dm.support[0] == 0 && dm.support[1] == 1 && dm.support[2] == 2,
                      "B2 min-p suffix");
    if (dt.support == dm.support) {
        std::cerr << "B: top-p and min-p discriminators produced identical supports\n";
        ++failures;
    }

    // B3: both filters in one row with the SAME parameters as B1/B2: the
    // sequential break (min-p cut first, then top-p over the remainder) cuts
    // token 2 (0.049787 < 0.05) and the top-p prefix over {0,1} cannot extend
    // it -> support {0,1}. A pipeline that applies min-p AFTER top-p, or ANDs
    // the two thresholds (join instead of sequential break), changes this.
    Cfg bc;
    bc.temperature = 1.0;
    bc.top_p       = 0.90;
    bc.min_p       = 0.05;
    double ub = oracle_uniform(bc.seed, 21, 1, 0u);
    const Draw db = draw(a, bc, 5, ub);
    failures += check("B3 combined: sequential break keeps {0,1}", db.support.size() == 2 &&
                          db.support[0] == 0 && db.support[1] == 1,
                      "B3 combined support");
    return failures;
}

// (C) top-k clamping: >20 clamps to 20, >domain clamps to domain, <=0 keeps
// min(20, domain); top_k in [1,19] keeps exactly top_k.
int discriminator_topk_clamp() {
    std::vector<double> a(20);
    for (int i = 0; i < 20; ++i) { a[static_cast<std::size_t>(i)] = round_to_bf16(1.0 + 1.0 * i); }
    int failures = 0;
    Cfg big;    // top_k=200 -> cap min(20, 20) = 20
    big.temperature = 1.0;
    big.top_k       = 200;
    double ub = oracle_uniform(big.seed, 31, 1, 0u);
    const Draw db = draw(a, big, 20, ub);
    failures += check("C1 top_k=200 -> 20 candidates (vocab clamp)", db.support.size() == 20,
                      "C1 vocab clamp");
    Cfg mid;    // top_k=7 -> 7
    mid.temperature = 1.0;
    mid.top_k       = 7;
    double um = oracle_uniform(mid.seed, 31, 1, 0u);
    const Draw dm = draw(a, mid, 20, um);
    failures += check("C2 top_k=7 -> 7 candidates", dm.support.size() == 7, "C2 top_k=7");
    Cfg none;   // top_k=0 -> min(20,20) = 20
    none.temperature = 1.0;
    double un = oracle_uniform(none.seed, 31, 1, 0u);
    const Draw dn = draw(a, none, 20, un);
    failures += check("C3 top_k=0 -> full min(20,vocab)", dn.support.size() == 20, "C3 default");
    (void)db;
    (void)dn;
    return failures;
}

// (D) min_p scale discriminator: the threshold is min_p * MAX_CANDIDATE_WEIGHT
// (un-normalized exp weight), NOT min_p * max normalized probability. The same
// fixture and min_p=0.05 drops the last candidate at T=1.0 (2.1170 vs 0.1293)
// but keeps it at T=1.05 (0.8266 vs 0.05). A probability-scale implementation
// fails exactly one of the two runs.
int discriminator_minp_scale() {
    std::vector<double> a(20);
    for (int i = 0; i < 20; ++i) { a[static_cast<std::size_t>(i)] = round_to_bf16(0.75 * i); }
    int failures = 0;
    Cfg c1;
    c1.temperature = 1.0;
    c1.min_p       = 0.05;
    c1.top_k       = 5;
    double u1 = oracle_uniform(c1.seed, 41, 1, 0u);
    const Draw d1 = draw(a, c1, 20, u1);
    failures += check("D1 T=1.00: min-p drops the last top-k candidate (4 kept)",
                      d1.support.size() == 4 && d1.support.back() == 15,
                      "D1 weight-scale drop");
    Cfg c2;
    c2.temperature = 1.08;
    c2.min_p       = 0.05;
    c2.top_k       = 5;
    double u2 = oracle_uniform(c2.seed, 41, 1, 0u);
    const Draw d2 = draw(a, c2, 20, u2);
    failures += check("D2 T=1.08: same min_p keeps all 5", d2.support.size() == 5,
                      "D2 weight-scale keep");
    if (d1.support.size() == d2.support.size()) {
        std::cerr << "D: min-p scale discriminators did not diverge\n";
        ++failures;
    }
    return failures;
}

// (E) temperature <= 0: pure greedy argmax over RAW logits (no penalties, no
// filters, no RNG); exact +0.0f/-0.0f ties resolve to the lower token id, and
// the -0.0f-only column still yields a token.
int discriminator_greedy_boundary() {
    // E1: +0.0f at token 0 and -0.0f at token 1, both canonicalize to key 0x8000;
    // the id tie-break picks token 0. token 2 (-1.0) is the greedy max anyway?
    // no: 0 > -1, so {0,1} win; token 0 (lower id) is the greedy pick.
    std::vector<double> a = {round_to_bf16(0.0), round_to_bf16(-0.0), round_to_bf16(-1.0)};
    int failures = 0;
    // Greedy oracle: min argmax over raw logits, higher value wins, lower id tie-breaks.
    int greedy_pick = 0;
    {
        double bv = -std::numeric_limits<double>::infinity();
        int bi    = 0;
        for (std::size_t v = 0; v < a.size(); ++v) {
            if (a[v] > bv || (a[v] == bv && static_cast<int>(v) < bi)) {
                bv = a[v];
                bi = static_cast<int>(v);
            }
        }
        greedy_pick = bi;
    }
    failures += check("E1 greedy: exact-zero tie -> lower id (token 0)", greedy_pick == 0,
                      "E1 greedy argmax tie");
    // E2: single -0.0f column: still selects that token (numeric zero is a value).
    std::vector<double> b = {round_to_bf16(-0.0)};
    double bmax = -std::numeric_limits<double>::infinity();
    int bi = 0;
    for (std::size_t v = 0; v < b.size(); ++v) {
        if (b[v] > bmax || (b[v] == bmax && static_cast<int>(v) < bi)) {
            bmax = b[v];
            bi = static_cast<int>(v);
        }
    }
    failures += check("E2 greedy: -0.0f column still yields a token", bi == 0, "E2 -0.0 argmax");
    // E3: positive logits dominate zeros: token 3 (4.0) wins regardless of zeros.
    std::vector<double> c = {round_to_bf16(0.0), -1.0, round_to_bf16(-0.0), 4.0};
    int bi3 = 0;
    double bv3 = -std::numeric_limits<double>::infinity();
    for (std::size_t v = 0; v < c.size(); ++v) {
        if (c[v] > bv3 || (c[v] == bv3 && static_cast<int>(v) < bi3)) {
            bv3 = c[v];
            bi3 = static_cast<int>(v);
        }
    }
    failures += check("E3 greedy: nonzero top wins over zeros", bi3 == 3, "E3 argmax");
    (void)greedy_pick;
    return failures;
}

// (F) counter-based RNG: a pure function of (seed, position, purpose, sub).
int discriminator_rng_key() {
    int failures = 0;
    const double u11 = oracle_uniform(31, 1, 1, 0u);
    const double u21 = oracle_uniform(31, 1, 1, 0u);
    const double u31 = oracle_uniform(31, 1, 1, 0u);
    failures += check("F1 identical key reproduces the draw",
                      u11 == u21 && u11 == u31, "F1 reproducibility");
    const double u12 = oracle_uniform(31, 2, 1, 0u);  // position 2
    failures += check("F2 position shift changes the draw", u11 != u12, "F2 position key");
    const double u13 = oracle_uniform(31, 3, 1, 0u);
    const double u13b = oracle_uniform(31, 3, 1, 0u);
    failures += check("F3 purpose stream is reproducible", u13 == u13b, "F3 purpose key");
    const double other_seed = oracle_uniform(32, 1, 1, 0u);
    failures += check("F4 seed change changes the draw", u11 != other_seed, "F4 seed key");
    std::cout << "    F numerics: pos1=" << u11 << " pos2=" << u12 << " pos3=" << u13
              << " seed32=" << other_seed << "\n";
    // The three draws must be mutually distinct (the key fields actually separate).
    if (!(u11 != u12 && u11 != other_seed && u12 != u13)) {
        std::cerr << "F: key fields did not separate the streams\n";
        ++failures;
    }
    return failures;
}

// (G) token_counts side effect: exactly the drawn token increments by one, and
// ONLY on the positive-temperature path (the greedy path must not touch counts).
int discriminator_counts_side_effect() {
    std::vector<double> a = {round_to_bf16(5.0), round_to_bf16(4.5), 4.0, 3.0, -1.0};
    const std::vector<int> counts = {0, 0, 1, 0, 0};
    int failures = 0;
    Cfg c;
    c.temperature = 1.0;
    c.top_k       = 3;
    c.seed        = 7;
    double u = oracle_uniform(c.seed, 3, 1, 0u);  // u = 0.566390...
    const Draw d = draw(a, c, 5, u);
    // u = 0.566390 > p0 = 0.5 -> the draw is token 1.
    failures += check("G1 stochastic: the drawn token is exactly the oracle draw",
                      d.picked == 1, "G1 draw identity");
    // The side effect must increment ONLY that token, by one.
    std::vector<int> after(counts);
    after[static_cast<std::size_t>(d.picked)] += 1;
    failures += check("G2 only the drawn token's count increments", after[1] == 1 &&
                          after[0] == 0 && after[2] == 1 && after[3] == 0 && after[4] == 0,
                      "G2 count increment");
    std::cout << "    G2 counts after draw: " << after[0] << " " << after[1] << " " << after[2]
              << " " << after[3] << " " << after[4] << "\n";
    (void)counts;
    return failures;
}

} // namespace

int main() {
    int failures = 0;
    failures += discriminator_penalties();
    failures += discriminator_filter_order();
    failures += discriminator_topk_clamp();
    failures += discriminator_minp_scale();
    failures += discriminator_greedy_boundary();
    failures += discriminator_rng_key();
    failures += discriminator_counts_side_effect();
    std::cout << (failures == 0 ? "OK" : "FAIL")
              << " independent FP64 sampling oracle ("
              << (failures == 0 ? 0 : failures) << " failure(s))\n";
    return failures == 0 ? 0 : 1;
}