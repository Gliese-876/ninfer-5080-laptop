#pragma once
#include "ninfer/types.h"
#include <cstddef>
#include <cstdint>
namespace ninfer::runtime {
struct AdmissionResources {
    std::uint32_t active_lanes     = 0;
    std::uint32_t main_kv_pages    = 0;
    std::uint32_t backend_kv_pages = 0;
};
} // namespace
