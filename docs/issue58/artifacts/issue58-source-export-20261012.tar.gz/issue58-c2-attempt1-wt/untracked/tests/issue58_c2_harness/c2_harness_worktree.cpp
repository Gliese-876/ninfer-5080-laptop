// WORKTREE variant: preserved Attempt 1 (live cumulative temporal_backfill_is_safe).
// Compiled with `-I <harness dir> -I <harness>/\_inc` (NOT the repo src path), so the
// worktree policy resolves to the self-contained _inc/runtime/engine/wt_admission_policy.h
// and its repo-internal includes resolve to the local _inc stubs.
#define ISSUE58_C2_VARIANT_WORKTREE 1
#include "c2_harness.cpp"
#include "runtime/engine/wt_admission_policy.cpp"