// BASELINE variant: pinned baseline 2c3510cd (frozen serial temporal_credit).
// Includes the same harness source as the worktree TU; the only difference is the policy
// translation unit (baseline policy .h/.cpp) and the #define that selects the temporal gate.
// Compiled into its own executable (test_issue58_c2_harness_baseline) with
//   -DISSUE58_C2_VARIANT_BASELINE=1 -I<tests/issue58_c2_harness/baseline>
#define ISSUE58_C2_VARIANT_BASELINE 1
#include "c2_harness.cpp"
#include "baseline_admission_policy.cpp"