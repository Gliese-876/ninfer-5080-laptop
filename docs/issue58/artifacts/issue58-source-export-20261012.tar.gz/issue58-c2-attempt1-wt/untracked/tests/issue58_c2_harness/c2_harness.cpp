// Issue #58 C2 starvation — discriminating temporal-decision harness (LOCAL ATTEMPT 2).
//
// This harness drives the REAL production admission-decision that `ConcurrentExecutor::
// try_admit_one` applies to the protected-head / backfill-candidate path, for two variants
// (compiled by the two translation units below). It replays the production `try_admit_one`
// structure in full — head physical gate -> protection -> Drain check -> candidate loop with
// the physical lane check, the persistent branch, and the TEMPORAL branch (the variant gate)
// -> admit — so any difference in observed admission/denial between the two variants is purely
// the temporal-gate (scheduler-policy) difference, which is the discriminating behavior under
// test (Issue #58 C2 starvation).
//
//   * baseline : pinned 2c3510cd — `work <= temporal_credit` (frozen serial credit), and
//                `admit_planned` decrements `temporal_credit -= service_work`.
//   * worktree : preserved Attempt 1 — `temporal_backfill_is_safe` live cumulative gate; the
//                frozen `temporal_credit` is telemetry-only (no longer the gate).
//
// The harness EXPLICITLY computes, at every step, the temporal obligation (frozen credit or
// live cumulative outstanding), the live donor frontier D, and the physical lane/KV bounds, so
// the head-fit invariant is checkable from the log without re-deriving it.

#include "variant_policy.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <map>
#include <span>
#include <stdexcept>
#include <vector>

namespace {

using namespace ninfer::runtime;

// --- Resource helpers (mirror admission_policy ResourceTotals) ----------------------
struct Totals {
    std::uint64_t lanes = 0, main = 0, backend = 0;
};
void add(Totals& t, const AdmissionResources& r) noexcept {
    t.lanes += r.active_lanes;
    t.main += r.main_kv_pages;
    t.backend += r.backend_kv_pages;
}
void sub(Totals& t, const AdmissionResources& r) {
    if (r.active_lanes > t.lanes || r.main_kv_pages > t.main ||
        r.backend_kv_pages > t.backend) {
        throw std::logic_error("resource subtraction underflow");
    }
    t.lanes -= r.active_lanes;
    t.main -= r.main_kv_pages;
    t.backend -= r.backend_kv_pages;
}
bool fits(const Totals& used, const AdmissionResources& c) noexcept {
    return used.lanes <= c.active_lanes && used.main <= c.main_kv_pages &&
           used.backend <= c.backend_kv_pages;
}

// --- Physical lane/KV model: the physical check `find_admission_lane` enforces --------
// A candidate is physically admissible if its reservation (lanes + KV pages) fits within the
// shared headroom (free lanes + free KV pages) for a single lane. This is the physical
// feasibility production checks BEFORE the backfill branch; it is a property of the
// reservation + capacity, independent of the temporal policy gate.
bool physical_admissible(const AdmissionResources& cand, const AdmissionResources& cap,
                         const Totals& used) {
    const std::uint64_t free_lanes =
        (cap.active_lanes > used.lanes) ? (cap.active_lanes - used.lanes) : 0;
    if (std::uint64_t(cand.active_lanes) > free_lanes) { return false; }
    const std::uint64_t free_main =
        (cap.main_kv_pages > used.main) ? (cap.main_kv_pages - used.main) : 0;
    if (std::uint64_t(cand.main_kv_pages) > free_main) { return false; }
    return true;
}
std::uint64_t free_lanes(const AdmissionResources& cap, const Totals& used) {
    return (cap.active_lanes > used.lanes) ? (cap.active_lanes - used.lanes) : 0;
}
std::uint64_t free_main(const AdmissionResources& cap, const Totals& used) {
    return (cap.main_kv_pages > used.main) ? (cap.main_kv_pages - used.main) : 0;
}

// --- The variant temporal gate (the production `try_admit_one` Temporal predicate) ----
//   baseline : work <= frontier && work <= frozen temporal_credit
//   worktree : work <= frontier && temporal_backfill_is_safe(...)   [live cumulative]
bool temporal_gate(const AdmissionProtection& prot,
                   const std::vector<ActiveAdmissionSnapshot>& active,
                   std::uint64_t work, std::uint32_t cand_lanes,
                   const AdmissionResources& cap) {
#if ISSUE58_C2_VARIANT_BASELINE
    (void)cand_lanes;
    return work <= protection_frontier_distance(prot, std::span(active)) &&
           work <= prot.temporal_credit;
#elif ISSUE58_C2_VARIANT_WORKTREE
    const std::span<const ActiveAdmissionSnapshot> sp(active);
    if (!(work <= protection_frontier_distance(prot, sp))) { return false; }
    return temporal_backfill_is_safe(prot, sp, work, cand_lanes, cap);
#else
    (void)prot; (void)active; (void)work; (void)cand_lanes; (void)cap;
    return false;
#endif
}

// --- Active-slot model (mirrors `slots_` / `active_admission_set`) -------------------
struct Slot {
    std::uint64_t id = 0;
    AdmissionResources resources{};
    std::uint64_t remaining = 0;
    std::uint64_t epoch = 0;
    BackfillClass backfill = BackfillClass::None;
};
struct World {
    std::map<std::uint64_t, Slot> slots;
    AdmissionResources capacity;
    std::vector<ActiveAdmissionSnapshot> active_set() const {
        std::vector<ActiveAdmissionSnapshot> v;
        for (const auto& [id, s] : slots) {
            if (s.id == 0 || s.remaining == 0) { continue; }
            ActiveAdmissionSnapshot a;
            a.request_id            = id;
            a.resources             = s.resources;
            a.remaining_work_quanta = s.remaining;
            a.backfill_epoch        = s.epoch;
            a.backfill_class        = s.backfill;
            v.push_back(a);
        }
        return v;
    }
    Totals used_total() const {
        Totals u{};
        for (const auto& [id, s] : slots) { add(u, s.resources); }
        return u;
    }
};

// --- Full `try_admit_one` replay for a blocked-head + one pending candidate (c) ----
// Reproduces the production decision for the temporal branch. `work` is the candidate's
// borrowed work; `phys` is the candidate's physical reservation. Returns what production
// would do (admit class, or none) — the discriminating measurement.
struct Verdict {
    BackfillClass admitted = BackfillClass::None;
    bool physical_ok = false;
    bool gate = false;
    std::uint64_t D = 0;
};

Verdict decide(const World& w, const AdmissionProtection& prot, std::uint64_t work,
               const AdmissionResources& phys) {
    Verdict v;

    const std::vector<ActiveAdmissionSnapshot> active = w.active_set();
    if (active.empty()) { throw std::logic_error("blocked head on idle engine"); }

    const std::span<const ActiveAdmissionSnapshot> sp(active.data(), active.size());
    const std::uint64_t D = protection_frontier_distance(prot, sp);
    v.D = D;

    if (protected_head_safe_without_temporal(prot, sp, w.capacity)) {
        v.admitted = BackfillClass::None;  // Drain: no admission this pass
        return v;
    }

    // candidate physical lane feasibility (find_admission_lane)
    const Totals used = w.used_total();
    v.physical_ok = physical_admissible(phys, w.capacity, used);
    if (!v.physical_ok) {
        return v;  // physically blocked -> candidate skipped (production `continue`)
    }

    BackfillClass backfill = BackfillClass::None;
    // (1) persistent branch (production `else`): cumulative future-frontier fit
    if (persistent_backfill_is_safe(prot, sp, phys, w.capacity)) {
        backfill = BackfillClass::Persistent;  // persistent branch: no temporal gate involved
    } else {
        // (2) temporal branch: the VARIANT GATE. `v.gate` already holds the real variant gate
        //     (baseline: `work <= frozen temporal_credit`; worktree: live-frontier && live
        //     cumulative `temporal_backfill_is_safe`). Temporal admission requires the gate.
        const std::uint32_t lanes = phys.active_lanes;
        v.gate = temporal_gate(prot, active, work, lanes, w.capacity);
        if (v.gate) { backfill = BackfillClass::Temporal; }
    }

    if (backfill == BackfillClass::None) { return v; }

    // decision is fully determined by (gate, physical, persistent/temporal branch); the slot
    // recording + baseline credit decrement (admit_planned_request) is applied by the caller
    // (main) so the world evolves production-faithfully after each admitted candidate.
    v.admitted = backfill;
    (void)D;
    return v;
}

}  // namespace

#include "c2_main.h"  // the shared main(): sets up the fixture + runs the discriminating case