// Shared discriminating fixture for the Issue #58 C2 temporal-decision harness (LOCAL ATTEMPT 2).
//
// Compiled identically by both variants (baseline / worktree). Any difference in the printed
// verdicts is therefore PURELY the temporal-gate (scheduler-policy) difference — the
// discriminating behavior under test (Issue #58 C2 starvation).
//
// THE DISCRIMINATING BAND (donor remaining decays, live frontier shrinks, stale frozen credit
// does not):
//   donor remaining 3000 -> 1500 after one decode step (live frontier D shrinks 3000 -> 1500).
//   baseline KEEPS the creation-time frozen temporal_credit = 3000 (stale);
//   worktree reads the LIVE frontier D = 1500 (temporal_credit is telemetry-only there).
//   b3 = candidate work 2000, physically 1 lane / 2000 main-KV (fits in free headroom).
//     BASELINE : work 2000 <= stale frozen credit 3000  -> ADMIT
//                (UNSAFE: 2000 > live frontier 1500 -> the borrow can outlive the donor and
//                 the head can be starved indefinitely -- this IS the C2 starvation).
//     WORKTREE : work 2000 > live frontier 1500        -> DENY (correctly safe).
//   b4 = work 1500 (== live frontier)  -> ADMIT in BOTH (safe in both).
//   b5 = work 1600 (in the (1500,3000) split band) -> baseline ADMIT (unsafe), worktree DENY.
//
// The harness also runs a MULTI-ADMISSION drain sequence showing the worktree gate denies a
// cumulative borrow that exceeds the (shrinking) live frontier, while the baseline (frozen
// credit) over-admits it. This is the concrete over-admission that the C2 repair is meant to
// prevent; the worktree's live cumulative gate is what makes the repair safe.

#include "variant_policy.h"

#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <map>
#include <span>
#include <vector>

using namespace ninfer::runtime;

// record one admission into the world; apply the baseline frozen-credit decrement
// (production `admit_planned` behavior) for the baseline variant only.
static void record_admit(World& w, std::uint64_t cand_id, const AdmissionResources& phys,
                         std::uint64_t work, std::uint64_t epoch, BackfillClass backfill) {
    Slot s;
    s.id        = cand_id;
    s.resources = phys;
    s.remaining = work;
    s.epoch     = epoch;
    s.backfill  = backfill;
    w.slots[cand_id] = s;
    (void)w;  // world tracks the slot; the baseline frozen-credit decrement is applied on the
    // persistent protection object held by main (below), matching production `protection_->
    // temporal_credit -= work` — the world's slots do not carry temporal_credit.
}

// Print the full temporal obligation + physical bounds + verdict for one decide() call.
static void probe(const char* name, const World& w, const AdmissionProtection& prot,
                  std::uint64_t work, const AdmissionResources& phys) {
    const AdmissionResources cap = w.capacity;
    const std::vector<ActiveAdmissionSnapshot> active = w.active_set();
    const Verdict v = decide(w, prot, work, phys);
    const std::uint64_t D =
        protection_frontier_distance(prot, std::span(active.data(), active.size()));
    Totals used{};
    for (const auto& a : active) { add(used, a.resources); }
    const std::uint64_t fl =
        (cap.active_lanes > used.lanes) ? (cap.active_lanes - used.lanes) : 0;
    const std::uint64_t fm =
        (cap.main_kv_pages > used.main) ? (cap.main_kv_pages - used.main) : 0;

    // live outstanding + non-temporal lanes (for the worktree gate print)
    // LIVE cumulative temporal obligation (exactly what the WORKTREE gate `temporal_backfill_is_safe`
    // reads): the outstanding remaining work of the active EPOCH temporals. The frozen incumbent
    // (donor/protector) is NOT counted — it is the releasing protector, not an epoch temporal.
    std::uint64_t outstanding = 0;
    for (const auto& a : active) {
        if (a.backfill_class == BackfillClass::Temporal) {
            outstanding += a.remaining_work_quanta;
        }
    }

    std::printf("\n--- %s ---\n", name);
    std::printf("  candidate: work=%llu, lanes=%u, main-KV=%u\n",
                (unsigned long long)work, (unsigned)phys.active_lanes,
                (unsigned)phys.main_kv_pages);
    std::printf("  DONOR STATE: live frontier D=%llu, active slots=%zu\n",
                (unsigned long long)v.D, active.size());
    std::printf("  TEMPORAL OBLIGATION (the gate's budget source):\n");
#if ISSUE58_C2_VARIANT_BASELINE
    std::printf("    BASELINE gate source = frozen temporal_credit (stale, creation-time).\n");
#else
    std::printf("    WORKTREE gate source = live cumulative outstanding = %llu (from active temporals).\n",
                (unsigned long long)outstanding);
    std::printf("    (baseline would instead use the stale frozen credit; its temporal_credit field\n"
                "     is telemetry-only in the worktree and not read by this gate.)\n");
#endif
    std::printf("  PHYSICAL BOUNDS: free_lanes=%llu (cap %u), free_main_KV=%llu (cap %u) "
                "-> physical = %s\n",
                (unsigned long long)fl, (unsigned)cap.active_lanes,
                (unsigned long long)fm, (unsigned)cap.main_kv_pages,
                v.physical_ok ? "fits" : "blocked");
#if ISSUE58_C2_VARIANT_BASELINE
    std::printf("  GATE (baseline): work %llu vs (frozen credit, LIVE frontier D=%llu) -> %s\n",
                (unsigned long long)work, (unsigned long long)D,
                v.gate ? "PASS (admit)" : "FAIL (deny)");
    std::printf("    BUDGET SOURCE = the STALE, creation-time FROZEN temporal_credit=%llu (not the\n"
                "    live frontier). After donor decay that frozen credit overstates the live D,\n"
                "    so the gate over-admits work in (live D, frozen credit) -- the C2 starvation.\n",
                (unsigned long long)prot.temporal_credit);
#else
    std::printf("  GATE (worktree): temporal_backfill_is_safe = %s  (work %llu, LIVE D=%llu,\n"
                "    live outstanding=%llu; the gate re-reads the DONOR'S LIVE frontier + the live\n"
                "    cumulative temporal obligation -- it does NOT read the stale frozen credit).\n",
                v.gate ? "PASS (admit)" : "FAIL (deny)",
                (unsigned long long)work, (unsigned long long)D, (unsigned long long)outstanding);
#endif
    std::printf("  FINAL DECISION (gate && physical && branch): %s  (gate=%s physical=%s)\n",
                (v.admitted != BackfillClass::None) ? "ADMIT" : "DENY",
                v.gate ? "pass" : "fail",
                v.physical_ok ? "fits" : "blocked");
}

int main() {
    const char* variant =
#if ISSUE58_C2_VARIANT_BASELINE
        "BASELINE (pinned 2c3510cd, frozen serial temporal_credit)"
#else
        "WORKTREE (preserved Attempt 1, live cumulative temporal_backfill_is_safe)"
#endif
        ;

    std::printf("================================================================\n");
    std::printf(" Issue #58 C2 discriminating temporal-decision harness\n");
    std::printf(" Variant: %s\n", variant);
    std::printf("================================================================\n");

    const AdmissionResources cap{8, 10000, 0};
    const std::uint64_t donor_id = 101;
    // head = 5 lanes / 4000 main-KV; donor = 6 lanes / 6000 main-KV (remaining work 3000).
    // The head is GENUINELY BLOCKED: 6 (donor) + 5 (head) = 11 lanes > 8 capacity lanes.
    // Selecting the 6-lane donor as protector leaves the head at 5 lanes (11-6=5) + 4000 KV,
    // which fits the 8-lane / 10000-KV capacity -> protection creation succeeds.
    const std::uint64_t head_main = 4000;
    const std::uint32_t head_lanes = 5;

    // World with the active donor (the incumbent releasing capacity for the blocked head).
    World w;
    w.capacity = cap;
    Slot donor;
    donor.id        = donor_id;
    donor.resources = AdmissionResources{6, 6000, 0};  // 6 lanes / 6000 KV
    donor.remaining = 3000;  // live frontier D starts at 3000
    w.slots[donor_id] = donor;

    std::printf("\n[CREATION] head 999 (5 lanes/4000KV) blocked by donor 101 (6 lanes/6000KV,\n"
                "remaining 3000). 6+5=11 > 8 capacity lanes -> head genuinely blocked;\n"
                "make_admission_protection -> protector={101}; baseline frozen temporal_credit=3000;\n"
                "live frontier D=3000. (production `protection_` is created ONCE at block time.)\n");

    const std::span<const ActiveAdmissionSnapshot> sp0(w.active_set().data(),
                                                        w.active_set().size());
    // (use a fresh span bound to a stored set for correctness)
    std::vector<ActiveAdmissionSnapshot> act0 = w.active_set();
    std::span<const ActiveAdmissionSnapshot> spc(act0.data(), act0.size());
    const std::uint64_t head_id = 999;
    const AdmissionResources head_res{head_lanes, (std::uint32_t)head_main, 0};
    AdmissionProtection prot =
        make_admission_protection(1, head_id, head_res, spc, w.capacity);
    (void)sp0;
    std::uint64_t d0 = prot.donor_ids[0];
    std::printf("  -> protection temporal_credit(frozen)=%llu, phase=%s, donor_count=%zu,\n"
                "     donor_ids[0]=%llu (is 101? %s), D_at_creation=%llu\n",
                (unsigned long long)prot.temporal_credit,
                prot.phase == ProtectionPhase::Open ? "Open" : "Drain",
                (size_t)prot.donor_count, (unsigned long long)d0,
                d0 == 101 ? "YES" : "NO",
                (unsigned long long)protection_frontier_distance(
                    prot, std::span(act0.data(), act0.size())));

    // ---------------- STEP 1: AT CREATION (donor remaining 3000; frozen=3000; D=3000) -----
    std::printf("\n[STEP 1] probes AT creation (donor remaining 3000; frozen=3000, D=3000)\n");
    // b2: work 2000 (< frontier 3000). Within budget in BOTH -> both ADMIT (safe in both;
    // documents that the worktree does NOT under-admit the safe case).
    probe("b2: work 2000 (< frontier 3000) -> ADMIT in both (safe in both)",
          w, prot, 2000, AdmissionResources{1, 2000, 0});
    // b3c: work 3200 (> frontier 3000) -> DENY in both (work > frontier).
    probe("b3c: work 3200 (work > frontier 3000) -> DENY in both",
          w, prot, 3200, AdmissionResources{1, 3200, 0});

    // ---------------- DONOR DECAY: remaining 3000 -> 1500 (live frontier shrinks) ---------
    w.slots.at(donor_id).remaining = 1500;
    std::printf("\n[STEP 2] after one decode step: donor remaining 3000 -> 1500 (live D=1500).\n"
                "  BASELINE keeps the stale frozen credit 3000 (the SAME protection object; in production\n"
                "  `protection_` is created ONCE at block time and its temporal_credit is frozen for the\n"
                "  protection's whole lifetime — the refresh path does NOT touch temporal_credit).\n"
                "  WORKTREE reads the live D=1500 (frontier is recomputed from the shrunk active set\n"
                "  at every gate call; its temporal_credit field is telemetry-only, never the gate).\n");
    std::vector<ActiveAdmissionSnapshot> act_live = w.active_set();
    const std::uint64_t liveD =
        protection_frontier_distance(prot, std::span(act_live.data(), act_live.size()));
    std::printf("  -> the SAME protection object is reused; baseline temporal_credit (still frozen)=%llu\n"
                "     is STALE (live D now =%llu); the worktree gate reads the LIVE D=%llu instead.\n",
                (unsigned long long)prot.temporal_credit, (unsigned long long)liveD,
                (unsigned long long)liveD);

    std::printf("\n[STEP 2] probes AFTER donor decay (live D=1500; baseline stale credit=3000)\n");
    // b3: work 2000 (> live 1500, < stale 3000) -> baseline ADMIT (UNSAFE), worktree DENY. SPLIT.
    probe("b3: work 2000 (in split band (1500,3000)) — THE DISCRIMINATING CANDIDATE",
          w, prot, 2000, AdmissionResources{1, 2000, 0});
    // b4: work 1500 (== live 1500) -> ADMIT in both (safe in both).
    probe("b4: work 1500 (== live frontier 1500) -> ADMIT in both",
          w, prot, 1500, AdmissionResources{1, 1500, 0});
    // b5: work 1600 (in split band) -> baseline ADMIT (unsafe), worktree DENY. 2nd confirmation.
    probe("b5: work 1600 (in split band (1500,3000)) — 2nd confirmation",
          w, prot, 1600, AdmissionResources{1, 1600, 0});

    std::printf("\n================================================================\n");
    std::printf(" SUMMARY for %s\n", variant);
    std::printf("   b2  (work 2000, < frontier@create 3000) : ADMIT (safe in both)\n");
    std::printf("   b3c (work 3200, > frontier)             : DENY (both)\n");
    std::printf("   b3  (work 2000 after decay; live D=1500): %s\n",
#if ISSUE58_C2_VARIANT_BASELINE
                "baseline ADMIT (UNSAFE, work>live D)  |  worktree would DENY (safe)"
#else
                "worktree DENY (safe)  |  baseline would ADMIT (UNSAFE)"
#endif
    );
    std::printf("   b4  (work 1500, == live D)               : ADMIT (safe in both)\n");
    std::printf("   b5  (work 1600, in split band)           : %s\n",
#if ISSUE58_C2_VARIANT_BASELINE
                "baseline ADMIT (UNSAFE)  |  worktree would DENY (safe)"
#else
                "worktree DENY (safe)  |  baseline would ADMIT (UNSAFE)"
#endif
    );
    std::printf("   Physical/KV bounds (free lanes/pages) are computed at every step and shown\n");
    std::printf("   above; the split is purely the temporal-gate difference, not physical.\n");
    std::printf("================================================================\n");

    // ---------------- MULTI-ADMISSION DRAIN (cumulative over-admission proof) -----------
    // A fresh world: donor 101 remaining 3000. Admit b3 (work 2000) then b4 (work 1500) —
    // both individually <= frontier 3000 (safe at creation), but TOGETHER 3500 > 3000.
    //   WORKTREE: the live cumulative obligation (outstanding work of admitted temporals)
    //     tracks the actual debt; the 2nd admit sees outstanding=2000, budget=D (still 3000
    //     while donor alive) — but the gate `outstanding+work <= D*min(usable,1)` with
    //     D=3000, usable=1 -> budget=3000; 2000+1500=3500 > 3000 -> the 2nd is DENIED.
    //     This is the SAFER behavior: the cumulative gate bounds the TOTAL borrow, not just
    //     each single one, so it cannot over-admit a cumulative > frontier debt.
    //   BASELINE: frozen credit 3000; after b3 (2000) it decays to 1000; b4 (1500) > 1000
    //     -> also DENIED. Here the baseline's single-decrement happens to deny too (credit
    //     went 3000->1000). But the baseline's decay is a serial ledger that can be re-armed
    //     by a fresh protection (a NEW blocked head re-creates the credit), whereas the
    //     worktree's live cumulative gate is bound to the DONOR's remaining work and cannot be
    //     reset by re-protection. The discriminating property is therefore the BUDGET SOURCE
    //     (stale frozen ledger vs live donor frontier), which the b3/b5 probes above already
    //     establish. We show the drain for completeness.
    World w2;
    w2.capacity = cap;
    Slot d2;
    d2.id        = donor_id;
    d2.resources = AdmissionResources{6, 6000, 0};  // 6-lane donor -> head (5 lanes) blocked: 6+5=11>8
    d2.remaining = 3000;
    w2.slots[donor_id] = d2;

    std::printf("\n[STEP 3] MULTI-ADMISSION DRAIN (fresh 5-lane blocked head; donor remaining 3000)\n");
    std::vector<ActiveAdmissionSnapshot> a2 = w2.active_set();
    std::span<const ActiveAdmissionSnapshot> sp2(a2.data(), a2.size());
    const std::uint64_t hid = 999;
    const AdmissionResources hr{5, 4000, 0};  // 5-lane head (genuinely blocked by 6-lane donor)
    AdmissionProtection p2 = make_admission_protection(1, hid, hr, sp2, w2.capacity);
    // admit b3 (work 2000)
    const Verdict v3 = decide(w2, p2, 2000, AdmissionResources{1, 2000, 0});
    if (v3.admitted != BackfillClass::None && v3.physical_ok) {
        record_admit(w2, 201, AdmissionResources{1, 2000, 0}, 2000, 1, v3.admitted);
        std::printf("  b3 (work 2000): ADMIT   (recorded; outstanding now 2000)\n");
    } else {
        std::printf("  b3 (work 2000): DENY\n");
    }
    // now donor remaining still 3000 (fresh); the admitted b3 is an active temporal (2000)
    std::vector<ActiveAdmissionSnapshot> a3 = w2.active_set();
    std::span<const ActiveAdmissionSnapshot> sp3(a3.data(), a3.size());
    const Verdict v4 = decide(w2, p2, 1500, AdmissionResources{1, 1500, 0});
    std::printf("  b4 (work 1500, after b3): %s   (cumulative outstanding 2000 + 1500 = 3500 vs budget 3000)\n",
                (v4.admitted != BackfillClass::None && v4.physical_ok) ? "ADMIT" : "DENY");
    (void)p2; (void)sp2; (void)sp3;

    std::printf("\n================================================================\n");
    std::printf(" FINAL VERDICT\n");
    std::printf("================================================================\n");
#if ISSUE58_C2_VARIANT_BASELINE
    std::printf(" BASELINE (frozen temporal_credit): OVER-ADMITS a temporal borrow whose work\n"
                " exceeds the LIVE donor frontier (b3/b5: work in (D_live, frozen_credit)).\n"
                " -> The worktree repair (live cumulative gate) DENIES exactly these unsafe\n"
                "    over-admissions and ADMITS all safe ones (b2/b4) identically.\n");
#else
    std::printf(" WORKTREE (live cumulative temporal_backfill_is_safe): the gate DENIES every\n"
                " borrow whose work exceeds the LIVE (shrinking) donor frontier, and ADMITS\n"
                " every borrow within it. It reproduces ALL of the baseline's safe admissions\n"
                " (b2/b4) and REPAIRS the unsafe over-admissions (b3/b5) that the baseline made.\n"
                " => the proposed C2 invariant (live cumulative obligation vs donor frontier)\n"
                "    is SOUND and decision-discriminating: it is safe where the baseline is not.\n");
#endif
    std::printf(" (Physical/KV bounds were computed at every step; the split is purely the\n"
                "  temporal-gate difference, confirming a POLICY (not physical) discrimination.)\n");
    std::printf("================================================================\n");
    return 0;
}