#pragma once
#include <cstdint>
namespace ninfer {
using TokenId = std::int32_t;
inline constexpr std::uint32_t kMaximumConcurrency = 8;
enum class FinishReason : std::uint32_t { None = 0, Complete, Length, Stop, Cancelled, Error = 100 };
} // namespace ninfer
