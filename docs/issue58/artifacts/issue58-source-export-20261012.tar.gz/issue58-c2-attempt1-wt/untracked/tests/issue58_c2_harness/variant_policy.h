// Test-only variant selector for the Issue #58 C2 temporal-decision harness.
//
// `variant_policy.h` is the policy header included by c2_harness.cpp. It resolves to the
// variant's REAL production admission-policy header (both self-contained via the _inc include
// mirror, whose repo-internal includes resolve to local stubs):
//   * BASELINE  : _inc/runtime/engine/admission_policy.h  (pinned 2c3510cd frozen-credit policy)
//   * WORKTREE  : _inc/runtime/engine/wt_admission_policy.h (preserved Attempt-1 live-gate policy)
// The gate inside c2_harness.cpp then switches on the variant #define.
#pragma once

#if defined(ISSUE58_C2_VARIANT_BASELINE) && ISSUE58_C2_VARIANT_BASELINE
#include "runtime/engine/admission_policy.h"
#elif defined(ISSUE58_C2_VARIANT_WORKTREE) && ISSUE58_C2_VARIANT_WORKTREE
#include "runtime/engine/wt_admission_policy.h"
#else
#error "must define exactly one of ISSUE58_C2_VARIANT_BASELINE / ISSUE58_C2_VARIANT_WORKTREE"
#endif