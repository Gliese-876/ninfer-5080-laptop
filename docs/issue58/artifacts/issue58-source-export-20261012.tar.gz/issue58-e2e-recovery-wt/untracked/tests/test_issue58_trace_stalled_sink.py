#!/usr/bin/env python3
"""Bounded trace-transport regression: discriminating proof of the stall fix.

Usage:
    test_issue58_trace_stalled_sink.py <healthy-bin> <stalled-bin>
    # OLD binary: argv = {0,1} <sink> (path); NEW binary: NINFER_C2_TRACE_PATH env.

Proves the bounded writer transport against the OLD synchronous writer
(evidence/test_stalled_regular_sink) on the same fault-injected, regular-file
sink, with the adversarial condition (a stalled regular-file write) active
for the WHOLE test until the external watchdog:

  (1) OLD, sink enabled : writer thread blocks in the sink syscall -> the
      external watchdog (timeout 15) kills the process -> RC124.
  (2) NEW, sink enabled : the writer thread is woken by the SIGALRM
      deadline (it is the only armed signal); the write is bounded, the sink
      is marked failed (no retry, no I/O in emit), stop() drains + joins
      (bounded), the main thread reaches full retirement, prints its marker
      and exits -> RC0. The adversarial condition was never removed: the
      fault-injected write stays entered-and-blocked for every record.
  (3) NEW, disabled     : pure control path, no I/O, bounded exit -> RC0.
  (4) OLD, disabled     : pure control path (pre-existing property) -> RC0.

Both (1) and (3) are bounded by the script's own watchdog (timeout -k 5 20
per leg); no leg can hang the host indefinitely.
"""
import os
import subprocess
import sys

KILL = [124, 137]


def main():
    if len(sys.argv) != 3:
        print("usage: %s <healthy-bin> <stalled-bin>" % sys.argv[0])
        return 2
    healthy, stalled = sys.argv[1], sys.argv[2]
    os.makedirs(os.path.dirname(healthy), exist_ok=True)
    sink = os.path.join(os.path.dirname(healthy), "stall.jsonl")
    os.makedirs(os.path.dirname(sink), exist_ok=True)
    results = {}
    for name, cmd in [
        ("old_stall_on_watchdog",  ["timeout", "-k", "5", "15", stalled, "1", sink]),
        ("old_stall_off",          ["timeout", "-k", "5", "15", stalled, "0", sink]),
        ("new_stall_on_watchdog",  ["timeout", "-k", "5", "15", "env", "NINFER_C2_TRACE_PATH=" + sink, healthy, "1"]),
        ("new_stall_off",          ["timeout", "-k", "5", "15", "env", "-u", "NINFER_C2_TRACE_PATH", healthy, "0"]),
    ]:
        cmd_out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 timeout=25)
        rc = cmd_out.returncode
        results[name] = (rc, cmd_out.stdout)
        print("%s: rc=%d\n---\n%s\n---" % (name, rc, cmd_out.stdout.decode("utf-8", "replace")[:1500]))

    old_on = results["old_stall_on_watchdog"][0]
    new_on = results["new_stall_on_watchdog"][0]
    new_on_out = results["new_stall_on_watchdog"][1]
    ok = True
    # (1) OLD + enabled: the old writer's main+writer threads are both stuck in
    # the entered stalled sink syscall -> external watchdog ends it -> RC124.
    if old_on not in KILL:
        print("CHECK old_stall_on_watchdog FAIL: expected RC124, got %d" % old_on)
        ok = False
    # (2) NEW + enabled: bounded transport -> full retirement despite the
    # active adverse condition -> RC0 with the retirement marker.
    if new_on != 0 or b"EMIT_AND_RETIREMENT_REACHED" not in new_on_out:
        print("CHECK new_stall_on_watchdog FAIL: rc=%d" % new_on)
        ok = False
    # (3) NEW + disabled: pure control path -> RC0 with marker.
    new_off_rc, new_off_out = results["new_stall_off"]
    if new_off_rc != 0 or b"EMIT_AND_RETIREMENT_REACHED" not in new_off_out:
        print("CHECK new_stall_off FAIL: rc=%d" % new_off_rc)
        ok = False
    # (4) OLD + disabled: control path -> RC0 with marker.
    old_off_rc, old_off_out = results["old_stall_off"]
    if old_off_rc != 0 or b"EMIT_AND_RETIREMENT_REACHED" not in old_off_out:
        print("CHECK old_stall_off FAIL: rc=%d" % old_off_rc)
        ok = False

    if not ok:
        print("STALLED_TRANSPORT_PROOF=FAIL")
        return 1
    print("STALLED_TRANSPORT_PROOF=PASS")
    print("OLD_WRITER_STALL_ON_RC=%d NEW_WRITER_STALL_ON_RC=%d" % (old_on, new_on))
    print("ADVERSE_CONDITION=ACTIVE_THROUGHOUT (fault-injected write entered "
          "before every record; never lifted until the external watchdog)")
    return 0


if __name__ == "__main__":
    sys.exit(main())