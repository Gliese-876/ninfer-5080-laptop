#!/usr/bin/env python3
"""Call-site regression ONLY; does not claim executor behavioral qualification."""
import pathlib
import re
import sys
source = pathlib.Path(sys.argv[1]).read_text()
checks = {
    "disabled_reason_guard": 'if (admission_trace().enabled()) {\n                trace_admission(head, "admission_attempt",' in source,
    "disabled_cancel_load": 'if (admission_trace().enabled())\n                trace_request(request, request->cancelled.load()' in source,
    "all_protection_resets_observed": all('trace_protection_retirement' in source[max(0, m.start()-140):m.start()] for m in re.finditer(r'protection_\.reset\(\)', source)),
    "drain_phase_record": 'protection_->phase = ProtectionPhase::Drain;\n                if (trace_entering_drain)\n                    trace_admission(head, "protection_drain"' in source,
    "retained_eviction_record": 'instance_.program->evict_retained_lane(retained_lane);\n                    trace_lane(request, "retained_evicted", retained_lane);' in source,
    "selected_lane_identity": 'trace_lane(request, "admission_selected", lane, backfill_epoch, backfill_class);' in source,
    "credit_consumption_record": 'protection_->temporal_credit -= summary.service_work_quanta;\n            trace_admission(request, "credit_consumed"' in source,
    "retained_slot_retirement": '? "lane_retained" : "lane_released", lane);' in source,
    "cancel_boundary_abort": 'instance_.program->abort_lane(lane);\n            trace_lane(request, "lane_aborted", lane);' in source,
    # Bounded-transport disabled gates (added with the stalled-sink fix).
    "disabled_queue_gate_submit": 'if (admission_trace().enabled())\n                trace_request(request, "queue_entry");\n        }\n        queue_cv_.notify_one();' in source,
    "disabled_queue_gate_resubmit": 'request->issue58_enqueued = Clock::now();\n            if (admission_trace().enabled())\n                trace_request(request, "queue_entry");\n        }\n\n        queue_cv_.notify_one();' in source,
    "disabled_cancel_intent_gate": 'request->cancelled.store(true, std::memory_order_release);\n        if (admission_trace().enabled())\n            trace_request(request, "cancel_requested");' in source,
    "no_enabled_gate_in_helpers": ('if (!trace.enabled()) return;' not in source) and ('if (!trace.enabled())\n            trace' not in source),
    "no_enabled_gate_at_call_sites": not re.search(r'if \(admission_trace\(\)\.enabled\(\)\)\s+\n\s+trace_lane|if \(admission_trace\(\)\.enabled\(\) &&', source),
}
for name, passed in checks.items():
    print(name, 'PASS' if passed else 'FAIL')
assert all(checks.values()), "missing telemetry source contract"
print("SOURCE_TRANSPORT_CONTRACT=PASS")
