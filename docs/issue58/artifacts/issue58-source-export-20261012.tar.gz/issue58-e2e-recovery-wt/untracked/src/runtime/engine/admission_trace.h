#pragma once

// Diagnostic records only: no inference content and no scheduling decisions.
//
// Bounded transport (stalled-sink recovery), no process-global sink timeout:
//   - emit() never performs file I/O and never blocks the producer in the
//     sink: a record is copied into a fixed-size bounded queue (full -> drop
//     with a counter). The producer acquires the transport lock only long
//     enough to copy the bounded record and wake the writer; it never
//     performs a sink write and never holds the lock across one.
//   - A dedicated writer thread (started only when a usable sink path is
//     given) owns all sink I/O. Each write is bounded by a 2-second
//     deadline: the writer arms its own alarm (SA_ONESHOT) for the write and
//     cancels it the moment the write returns, so no alarm state survives a
//     write. The writer's signal mask blocks the alarm signal, so a pending
//     deadline pre-empts ONLY the writer thread; every other thread of the
//     process (request I/O, thread pools, process shutdown) keeps the
//     default disposition and can never be pre-empted by this transport's
//     deadline. No process-global sink timeout: the armed alarm belongs
//     exclusively to the writer and never survives its write's bounded
//     lifetime.
//   - A failed/broken sink (write error, or a write abandoned at its
//     deadline) is marked failed: the queue drains to the cap and later
//     records drop without retry; the primary execution path is never
//     affected.
//   - Retirement is bounded and complete: stop() sets an explicit writer
//     lifecycle state and publishes the stop predicate + notify under the
//     transport lock (the writer observes it on its next wait, so it always
//     exits), then RELEASES the lock and only then joins; the join is never
//     executed with the transport lock held, so it cannot deadlock or span
//     an unbounded sink I/O. A process-lifetime atexit guard makes the
//     static global's shutdown exactly once (re-entrant or
//     post-static-destruction calls cannot re-enter it).
//   - When disabled (no usable path) every method returns at the first
//     enabled() branch: no threads, no queue, no extra predicates/guards,
//     and no extra scheduling work.
#include <atomic>
#include <cctype>
#include <chrono>
#include <climits>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fcntl.h>
#include <mutex>
#include <signal.h>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>

namespace ninfer::runtime {
class AdmissionTrace {
public:
    AdmissionTrace() noexcept : AdmissionTrace(std::getenv("NINFER_C2_TRACE_PATH")) {}
    explicit AdmissionTrace(const char* path) noexcept {
        if (!path || !*path) return;  // Disabled: no threads, no queue, no I/O.
        fd_ = ::open(path, O_WRONLY | O_APPEND | O_CREAT | O_CLOEXEC, 0600);
        struct stat info{};
        if (fd_ >= 0 && (::fstat(fd_, &info) != 0 || !S_ISREG(info.st_mode))) {
            ::close(fd_);
            fd_ = -1;
        }
        if (fd_ < 0) return;  // Malformed sink -> remain disabled: no I/O path.
        {
            std::lock_guard lock(mutex_);
            active_ = true;
            writer_state_ = WriterState::Starting;
        }
        writer_ = std::thread(&AdmissionTrace::writer_loop, this);
    }
    // Bounded, idempotent, complete retirement: stop predicate published
    // under the lock, lock released, then the writer is joined (the join is
    // never executed with the transport lock held, so it cannot deadlock or
    // span an unbounded sink I/O).
    void stop() noexcept {
        if (!active_) return;  // Idempotent; retired sinks stay retired.
        {
            std::lock_guard lock(mutex_);
            writer_state_ = WriterState::Stopping;
            writer_stop_ = true;  // Published under the lock: the writer's
            // next wait re-evaluation observes it and exits.
            writer_cv_.notify_all();
        }
        // Lock released: the writer either finished its drain or is inside a
        // bounded (2 s deadline) write; the join therefore always completes
        // in bounded time.
        if (writer_.joinable()) { writer_.join(); }
        writer_state_ = WriterState::Stopped;
        if (fd_ >= 0) { ::close(fd_); fd_ = -1; }
        active_ = false;
        retired_.store(true, std::memory_order_release);
    }
    AdmissionTrace(const AdmissionTrace&) = delete;
    AdmissionTrace& operator=(const AdmissionTrace&) = delete;
    bool enabled() const noexcept { return fd_ >= 0; }
    // True after stop(); later stop() calls are no-ops (exactly-once guard).
    bool retired() const noexcept { return retired_.load(std::memory_order_relaxed); }
    // Records dropped on a full bounded queue (diagnostic only).
    std::uint64_t dropped() const noexcept {
        return dropped_.load(std::memory_order_acquire);
    }
    static std::int64_t now_ns() noexcept {
        return std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    }
    // Fields are exclusively trusted fixed-format numeric/internal enum
    // values: no sink content can carry inference payloads into the log.
    // Record-only: no I/O, no lock held across any sink write, no retry on a
    // broken sink.
    void emit(const char* event, std::uint64_t id, const char* fields = "") noexcept {
        if (!enabled()) return;  // Disabled path: one branch, nothing else.
        if (failed_) {  // Broken/stalled sink: drop, do not retry.
            dropped_.fetch_add(1, std::memory_order_relaxed);
            return;
        }
        char record[4096];
        const int size = std::snprintf(record, sizeof(record),
            "{\"schema\":1,\"pid\":%ld,\"mono_ns\":%lld,\"event\":\"%s\",\"request_id\":%llu%s}\n",
            static_cast<long>(::getpid()), static_cast<long long>(now_ns()), event,
            static_cast<unsigned long long>(id), fields);
        if (size <= 0 || static_cast<std::size_t>(size) >= sizeof(record)) return;
        std::lock_guard lock(mutex_);
        if (queue_.size() >= kQueueCap) {
            dropped_.fetch_add(1, std::memory_order_relaxed);
            return;
        }
        std::string text;
        text.assign(record, static_cast<std::size_t>(size));
        queue_.push_back(std::move(text));
        writer_cv_.notify_one();
    }
private:
    // Explicit writer lifecycle: no implicit "active thread" assumption.
    // Starting: spawned, first wait pending. Running: consuming the queue.
    // Stopping: stop() published its predicate; the writer drains, then exits.
    // Stopped: joined; the sink is retired and never re-armed.
    enum class WriterState { Starting, Running, Stopping, Stopped };
    static constexpr std::size_t kQueueCap = 512;  // Bounded backpressure.
    static constexpr std::uint64_t kWriteDeadlineMs = 2000;

    // The writer's private alarm: armed per write (SA_ONESHOT), cancelled the
    // moment the write returns; its pending window pre-empts only the writer
    // (whose mask blocks SIGALRM) and never survives the write.
    static void alarm_sig_handler(int) { ::raise(SIGALRM); }

    // Writer's in-loop write deadline: the alarm is armed for the writer's
    // blocked SIGALRM only, then cancelled the moment the write returns.
    // No signal state survives a write; no other thread is ever pre-empted.
    void writer_loop() {
        // Block SIGALRM in the writer only: its own pending alarm then
        // pre-empts only this thread; all other threads keep the default
        // SIGALRM disposition.
        const sigset_t alarm_block = [&] {
            sigset_t set{};
            sigemptyset(&set);
            sigaddset(&set, SIGALRM);
            return set;
        }();
        (void)pthread_sigmask(SIG_BLOCK, &alarm_block, nullptr);
        for (;;) {
            {
                std::unique_lock<std::mutex> lock(mutex_);
                writer_state_ = WriterState::Running;  // Under the lock: stop()
                // also mutates it under the same lock, so the two orders never
                // interleave unsynchronized.
                writer_cv_.wait(lock, [this] {
                    return failed_ || writer_stop_ || !queue_.empty();
                });
            }
            // No lock held from here: the record is drained, and any sink
            // write (with or without its 2 s deadline) never overlaps a
            // held lock.
            if (writer_state_ == WriterState::Stopped) { break; }  // stop() joined us.
            if (writer_stop_ || failed_) {  // Retirement / failure drain.
                std::lock_guard drain_lock(mutex_);
                if (queue_.empty()) { break; }
                queue_.pop_front();
                continue;
            }
            std::string rec;
            {
                std::lock_guard lock(mutex_);
                if (queue_.empty()) { continue; }
                rec = std::move(queue_.front());
                queue_.pop_front();
            }
            if (failed_) { continue; }
            // Sink I/O with a 2 s deadline: arm the writer's alarm (its
            // blocked mask confines any pre-emption to this thread), run the
            // write, then cancel the alarm the moment the write returns. A
            // write abandoned at the deadline, or a write error, marks the
            // sink failed; no other thread is ever pre-empted.
            struct sigaction arming{};
            arming.sa_handler = alarm_sig_handler;
            arming.sa_flags = SA_ONESHOT;
            sigemptyset(&arming.sa_mask);
            (void)::sigaction(SIGALRM, &arming, nullptr);  // Writer thread only.
            ::alarm(kWriteDeadlineMs / 1000);
            const ssize_t written = ::write(fd_, rec.data(), rec.size());
            (void)::alarm(0);  // Cancel the writer's own alarm; nothing pending.
            (void)pthread_sigmask(SIG_UNBLOCK, &alarm_block, nullptr);
            (void)::sigaction(SIGALRM, nullptr, nullptr);  // Restore SIG_DFL.
            const bool deadline_fired = (written < 0 && errno == EINTR);
            if (written != static_cast<ssize_t>(rec.size()) || deadline_fired) {
                std::lock_guard lock(mutex_);
                failed_ = true;  // Stalled or failed sink: no retry, no I/O in emit.
                writer_cv_.notify_all();
            }
        }
    }

    int fd_ = -1;
    bool active_ = false;
    std::atomic<bool> retired_{false};
    std::atomic<WriterState> writer_state_{WriterState::Starting};
    bool writer_stop_ = false;
    bool failed_ = false;
    std::atomic<std::uint64_t> dropped_{0};
    std::deque<std::string> queue_;
    std::thread writer_;
    std::mutex mutex_;
    std::condition_variable writer_cv_;
    // Sink descriptors are created once and never re-armed after retirement.
};

inline AdmissionTrace& admission_trace() noexcept {
    static AdmissionTrace trace;
    // At program exit the static destructor would join the writer while it
    // may be inside a bounded syscall; the atexit-registered, exactly-once
    // guard retires the sink first, so destruction is bounded.
    static struct RetireAtExit {
        static void mark() { admission_trace().stop(); }
        RetireAtExit() {
            static std::atomic<bool> once{false};
            bool expected = false;
            if (once.compare_exchange_strong(expected, true)) { ::atexit(mark); }
        }
    } retire;
    if (trace.retired()) return trace;  // Already retired: no re-entry.
    return trace;
}
} // namespace ninfer::runtime