#pragma once

#include "runtime/engine/admission_policy.h"
#include <array>
#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <mutex>
#include <sys/stat.h>
#include <unistd.h>

namespace ninfer::runtime {

// Diagnostic only: no pipes, sockets, worker threads, exceptions, or stderr fallback.
// A missing/invalid sink disables these additional records. Existing legacy traces
// retain their original behavior. One append write owns each bounded record.
class AdmissionTrace {
public:
    AdmissionTrace() noexcept {
        const char* enabled = std::getenv("NINFER_ADMISSION_TRACE");
        const char* path = std::getenv("NINFER_ADMISSION_STATE_TRACE_PATH");
        if (!enabled || enabled[0] != '1' || enabled[1] != '\0' || !path || !*path) { return; }
        fd_ = ::open(path, O_WRONLY | O_APPEND | O_CREAT | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW, 0600);
        struct stat info{};
        if (fd_ >= 0 && (::fstat(fd_, &info) != 0 || !S_ISREG(info.st_mode))) {
            ::close(fd_);
            fd_ = -1;
        }
    }
    ~AdmissionTrace() { if (fd_ >= 0) { ::close(fd_); } }
    AdmissionTrace(const AdmissionTrace&) = delete;
    AdmissionTrace& operator=(const AdmissionTrace&) = delete;

    [[nodiscard]] bool enabled() const noexcept { return fd_ >= 0; }

    void join(std::uint64_t http, std::uint64_t executor, const char* protocol) noexcept {
        if (!enabled()) { return; }
        std::array<char, 512> line{};
        const int n = std::snprintf(line.data(), line.size(),
            "[HTTP-EXECUTOR] pid=%ld http=%llu executor=%llu protocol=%s\n",
            static_cast<long>(::getpid()), ull(http), ull(executor), protocol);
        append(line.data(), n, line.size());
    }

    void state(const char* event, std::uint64_t head, std::uint64_t request,
               const AdmissionProtection* protection,
               std::span<const ActiveAdmissionSnapshot> active,
               std::uint64_t queue_wait_ms, const char* reason) noexcept {
        if (!enabled()) { return; }
        std::array<char, 2048> line{};
        int n = std::snprintf(line.data(), line.size(),
            "[ADMISSION-STATE] pid=%ld event=%s head=%llu request=%llu "
            "protection_epoch=%llu protection_phase=%s temporal_credit=%llu "
            "frontier=%llu queue_wait_ms=%llu reason=%s donor_count=%zu donors=",
            static_cast<long>(::getpid()), event, ull(head), ull(request),
            ull(protection ? protection->epoch_id : 0),
            !protection ? "none" : protection->phase == ProtectionPhase::Drain ? "drain" : "open",
            ull(protection ? protection->temporal_credit : 0),
            ull(protection ? protection_frontier_distance(*protection, active) : 0),
            ull(queue_wait_ms), reason, protection ? protection->donor_count : 0);
        if (n < 0 || static_cast<std::size_t>(n) >= line.size()) { return; }
        if (protection) {
            for (std::size_t i = 0; i < protection->donor_count && i < kMaximumConcurrency; ++i) {
                const auto id = protection->donor_ids[i];
                std::uint64_t remaining = 0;
                for (const auto& a : active) {
                    if (a.request_id == id) { remaining = a.remaining_work_quanta; break; }
                }
                const int added = std::snprintf(line.data() + n, line.size() - n,
                    "%s%llu:%llu", i ? "," : "", ull(id), ull(remaining));
                if (added < 0 || static_cast<std::size_t>(added) >= line.size() - n) { return; }
                n += added;
            }
        }
        if (static_cast<std::size_t>(n) + 1 >= line.size()) { return; }
        line[n++] = '\n';
        append(line.data(), n, line.size());
    }

private:
    static unsigned long long ull(std::uint64_t n) noexcept { return static_cast<unsigned long long>(n); }
    void append(const char* data, int n, std::size_t capacity) noexcept {
        if (n <= 0 || static_cast<std::size_t>(n) >= capacity) { return; }
        std::lock_guard lock(mutex_);
        if (fd_ < 0 || failed_) { return; }
        // Never retry a failed/short write, never propagate diagnostic failure.
        if (::write(fd_, data, static_cast<std::size_t>(n)) != n) { failed_ = true; }
    }
    int fd_ = -1;
    bool failed_ = false;
    std::mutex mutex_;
};

inline AdmissionTrace& admission_trace() noexcept {
    static AdmissionTrace trace;
    return trace;
}

} // namespace ninfer::runtime
