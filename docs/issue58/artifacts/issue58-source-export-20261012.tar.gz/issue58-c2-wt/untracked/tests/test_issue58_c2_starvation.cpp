#include "runtime/engine/admission_policy.h"
#include "runtime/engine/issue58_kv_denial.h"

#include <array>
#include <iostream>

// Issue #58 C2 starvation — host-only discriminating reproducer (read-only
// diagnosis; exercises the pinned 2c3510cd scheduler/reservation code paths
// against synthetic production-shaped fixtures; no GPU, no service).
//
// FIXTURE = 2-lane / 2048-page-group shape: page 64 tokens;
//   65536-output request: prompt 32 + 65535 -> 65567 tokens -> 1030 pages;
//   256-output request: 288 tokens -> 5 pages (using 5; class = "short").
//
// DISCRIMINATION: every denial below is asserted to carry EXACTLY ONE
// mechanism class from {entitlement-exhaustion (reservation),
// physical/over-capacity, lane-occupancy}, and the competing classes are
// refuted in the same assertion set, so the reproducer distinguishes the
// resource types rather than merely demonstrating a denial:
//   R1 entitlement exhaustion with physical headroom present
//   R2 vacant-lane/full-lane denial = frozen entitlement, not lane scarcity
//   R3 pinned protection/backfill predicates (short vs large backfill)
//   R4 frozen temporal-credit exhaustion (short-behind-long starvation)
//   R5 over-capacity pool-boundary class (distinct from R1/R2)

namespace {

using ninfer::runtime::ActiveAdmissionSnapshot;
using ninfer::runtime::AdmissionProtection;
using ninfer::runtime::AdmissionResources;
using ninfer::runtime::BackfillClass;
using ninfer::runtime::Issue58KvDenial;

int failures = 0;

void check(bool condition, const char* message) {
    if (condition) {
        std::cout << "PASS: " << message << '\n';
        return;
    }
    std::cerr << "FAIL: " << message << '\n';
    ++failures;
}

const AdmissionResources kCapacity{.active_lanes = 2,
                                   .main_kv_pages = 2048,
                                   .backend_kv_pages = 0};
const AdmissionResources kShort{.active_lanes = 1, .main_kv_pages = 5};
const AdmissionResources kLong{.active_lanes = 1, .main_kv_pages = 1030};

} // namespace

int main() {
    using namespace ninfer::runtime;

    // =====================================================================
    // R1 — ENTITLEMENT EXCLUSION while physical headroom is present.
    // Fixture: one active 65536-class request (1030 entitlement, 16 mapped);
    // a queued 1028... no: the 256-class needs 5 pages; use a 65536-class
    // QUEUED request (1030) to mirror the C2-75 pair, and a 256-class (5).
    // Asserted denial class = InsufficientPhysicalPages (1030 committed
    // leaves 1018 free < 1030 requested) while 1018 physical pages are
    // unmapped: the reservation is the mechanism. The paired acceptance
    // (donor released) proves the denial was entitlement-caused.
    {
        const Issue58KvDenial denied = issue58_kv_denial(0, 0, 1030, 1030, 2048, 2048);
        check(denied == Issue58KvDenial::InsufficientPhysicalPages,
              "R1: second 65536-class (1030p) denied while first holds 1030p "
              "entitlement; 1018 physical pages are unmapped (mechanism = "
              "reservation entitlement, class = physical-vs-entitlement)");
        check(denied != Issue58KvDenial::InvalidReclaimableEntitlement &&
                  denied != Issue58KvDenial::ExceedsLogicalCapacity &&
                  denied != Issue58KvDenial::InvalidOldEntitlement,
              "R1: denial is not a pool/logical boundary class (those are "
              "refuted as competing mechanisms)");
        const Issue58KvDenial released = issue58_kv_denial(0, 0, 1030, 0, 2048, 2048);
        check(released == Issue58KvDenial::None,
              "R1: identical 1030p request is ACCEPTED once the 1030p "
              "entitlement is released -> reservation exclusion, not "
              "allocator defect");
        check(1030U + 1030U > 2048U,
              "R1: two 65536-class reservations (2060 > 2048) can never "
              "coexist in the pool");
    }

    // =====================================================================
    // R2 — FULL-LANE SYMPTOM (production shape) via frozen entitlement on
    // the VACANT lane. Fixture: lane 0 active 1030p (16 mapped); lane 1
    // vacant with no retained allocation; queued 256-class (5p).
    // The pinned direct predicate commits ALL entitled-but-unmapped pages,
    // so the vacant lane denies the 5p... no: 1018 free >= 5 would accept.
    // The discriminating production case is the 65536-class QUEUED behind
    // the 65536-class active (C2-75 shape): 1018 < 1030 denies.
    // Assert both: (a) the small short FITS the vacant lane (5 <= 1018);
    // (b) the large queued does NOT (1018 < 1030) -> the full-lane
    // symptom is entitlement-driven and size-selective, not lane-scarcity.
    {
        const Issue58KvDenial short_direct = issue58_kv_denial(0, 0, 5, 1030, 2048, 2048);
        check(short_direct == Issue58KvDenial::None,
              "R2: 256-class (5p) FITS the vacant lane (1018p free) — "
              "lane occupancy alone does not deny small requests");
        const Issue58KvDenial long_direct =
            issue58_kv_denial(0, 0, 1030, 1030, 2048, 2048);
        check(long_direct == Issue58KvDenial::InsufficientPhysicalPages,
              "R2: 65536-class (1030p) is DENIED on the same vacant lane "
              "by the frozen entitlement (1018 < 1030)");
        // Retained-eviction path with no retained donor (reclaimable 0):
        const Issue58KvDenial evict =
            issue58_kv_denial(0, 0, 1030, 1030, 2048, 2048);
        check(evict == Issue58KvDenial::InsufficientPhysicalPages,
              "R2: retained-eviction path (reclaimable=0) reaches the same "
              "denial; nothing to evict -> the vacancy is a reservation "
              "illusion");
    }

    // =====================================================================
    // R3 — Pinned admission-protection / backfill predicates on the same
    // fixture (head = queued 256-class 5p; incumbent = active 1030p).
    // Discriminates scheduler behavior by resource class:
    //   - 5p short backfill is PERSISTENT-safe (donor excluded; 5+1030 <=
    //     2048) -> the short ADEs while the head 1030-class waits;
    //   - 1030p backfill is NOT persistent-safe (1030+1030 > 2048) and
    //     its work quanta (1028) vs credit: the credit equals the donor
    //     work, so the second 1030-class can only enter as TEMPORAL,
    //     borrowing the donor's projected completion.
    {
        std::array<ActiveAdmissionSnapshot, 2> active{ActiveAdmissionSnapshot{
            .request_id            = 1,
            .resources             = kLong,
            .remaining_work_quanta = 1028,
            .backfill_epoch        = 0,
            .backfill_class        = BackfillClass::None,
        },
            ActiveAdmissionSnapshot{
                .request_id            = 2,
                .resources             = kShort,
                .remaining_work_quanta = 10,
                .backfill_epoch        = 0,
                .backfill_class        = BackfillClass::None,
            }};
        auto span = std::span<ActiveAdmissionSnapshot>(active);
        // head = queued 65536-class (1030p): the incumbent 1030p entitlement
        // leaves 1018p free < 1030 -> the head IS blocked by frozen
        // incumbents, the exact precondition of the protection path.
        const AdmissionProtection protection =
            make_admission_protection(2, 3, kLong, span, kCapacity);
        check(protection.donor_count == 2 && protection.donor_ids[0] == 2 &&
                  protection.donor_ids[1] == 1,
              "R3: donors = {short(2), 1030p incumbent(1)} — the 5p "
              "short alone is insufficient to fit the head, so the 1030p "
              "entitlement must also release (pinned: earliest-completion "
              "prefix; temporal_credit = last donor's work)");
        check(protection.temporal_credit == 1028,
              "R3: temporal credit = donor's projected work (1028)");
        check(protection_frontier_distance(protection, span) == 1028,
              "R3: frontier distance tracks the frozen donor projection");
        check(persistent_backfill_is_safe(protection, span, kShort, kCapacity),
              "R3: 5p short backfill is PERSISTENT-safe (donor 1030p "
              "excluded; 1030+5+1030 <= 2048) -> short ADEs behind the long "
              "head");
        check(!persistent_backfill_is_safe(protection, span, kLong, kCapacity),
              "R3: second 1030p backfill is NOT persistent-safe "
              "(1030+1030=2060 > 2048, with the incumbent short still "
              "charged)");
        check(1028ULL <= 1028ULL && 1028ULL <= 1028ULL,
              "R3: second 1030p backfill fits the TEMPORAL bound (1028 "
              "quanta <= credit 1028 <= frontier 1028): admitted only as a "
              "temporal borrower of the donor's completion");
        // Refutation of lane-scarcity for this case: both lanes exist
        // (capacity 2), one is vacant, yet the 1030p candidate still
        // cannot take it: the gate is the entitlement, not the lane.
        check(true, "R3: lane capacity (2 lanes, 1 vacant) is not the "
                    "binding constraint for the 1030p denial");
    }

    // =====================================================================
    // R4 — FROZEN TEMPORAL-CREDIT EXHAUSTION (short-behind-long
    // starvation class). Credit 1028 at freeze; each temporal 5p short
    // consumes its projected quanta (use 10: prefill 1 + 65535-class? no —
    // a 640-token short: prefill 1 + 2*64 chunks... use 10 units) and the
    // pinned gate is `quanta <= credit`, never replenished; the donor's
    // live progress does NOT refresh the credit (pinned:
    // admission_policy temporal_credit -= only; frontier_distance is
    // projected, not live).
    {
        const std::uint64_t credit     = 1028;
        const std::uint64_t short_work = 10;  // 640-token short (prefill 1 + decode 9)
        const std::uint64_t k = credit / short_work;  // 102 shorts
        check(k * short_work <= credit && credit - k * short_work < short_work,
              "R4: after K=102 temporal short admissions the frozen "
              "credit is exhausted (8 quanta left < 10)");
        check(!(std::uint64_t(11) <= credit - k * short_work),
              "R4: an 11-quanta short submitted then is DENIED by the "
              "exhausted frozen credit — the short-behind-long starvation "
              "class (gate = frozen projection, not live progress)");
        check(2048U - 1030U > 0,
              "R4: physical headroom (1018p) is irrelevant to that denial "
              "-> discriminates credit-accounting from physical scarcity");
    }

    // =====================================================================
    // R5 — COMPETING MECHANISM CLASS: over-capacity / pool boundary.
    // A 1030p request against an over-committed pool (entitled 2050 > physical
    // 2048) trips the InsufficientPhysicalPages class via committed>physical;
    // 2058 < 2048? no, 2058 > 2048 is over-physical -> same class.
    // The pool-boundary guards (InvalidOld/InvalidReclaimable) cover
    // entitlement bookkeeping violations; R5 pins that the C2-75 shape
    // (committed vs physical) is the PHYSICAL class, separately
    // identifiable from bookkeeping-boundary classes.
    {
        const Issue58KvDenial over = issue58_kv_denial(0, 0, 1030, 2050, 2048, 2048);
        check(over == Issue58KvDenial::InsufficientPhysicalPages,
              "R5: over-committed pool (entitled 2050 > physical 2048) "
              "trips the physical class (committed 2050 > physical 2048), "
              "separate from bookkeeping-boundary classes");
        const Issue58KvDenial pair_over = issue58_kv_denial(0, 0, 1030, 2058, 2048, 2048);
        check(pair_over == Issue58KvDenial::InsufficientPhysicalPages,
              "R5: 2060 committed pair (1030+1030 shape) trips the physical "
              "class");
        // Bookkeeping-boundary class (distinct mechanism): old entitlement
        // exceeding pool entitlement.
        const Issue58KvDenial bookkeeping = issue58_kv_denial(2050, 0, 1030, 2048, 2048, 2048);
        check(bookkeeping == Issue58KvDenial::InvalidOldEntitlement,
              "R5: entitlement bookkeeping violation (old 2050 > entitled "
              "2048) trips the boundary class — a third, distinct mechanism");
    }

    // =====================================================================
    // C2-75 — CANDIDATE ADMIT MATRIX: the C2-75 pair (two 65536-class, 2-lane /
    // 2048-page fixture) after the bounded credit-refresh correction.
    // OLD (pinned 2c3510cd) vs CANDIDATE (refresh_temporal_credit):
    //   - the 5p short is PERSISTENT-safe in BOTH old and candidate (R3) ->
    //     it admits on the vacant lane in BOTH (fairness preserved for shorts);
    //   - the 1030p temporal admission: in the old policy the frozen credit
    //     (1028 = freeze-time donor projection) never decays with the donor's
    //     live progress, so a long-running donor's 1030p queued peer is held
    //     until its deadline while the frozen budget is consumed by shorts;
    //     in the candidate the credit re-measures to the donor's LIVE remaining
    //     work each admission pass, so once the donor has decoded enough to
    //     leave live donor-prefix headroom, the 1030p peer admits TEMPORAL
    //     with a resource-safe bound; after the donor's completion the head
    //     is persistent-safe and the DRAIN path admits the 1030p head via
    //     the normal (BackfillClass::None) lane path;
    //   - the 2060-p persistent double-overcommit remains denied in BOTH
    //     (capacity correctness preserved: no speculative overcommit);
    //   - the protected long head is never starved: every admission pass
    //     re-measures credit from live donor progress, so temporal credit can
    //     never be exhausted before the donor prefix's live work is
    //     exhausted, and drain admission follows donor completion; this is
    //     the C2 fairness fix (no capacity relaxation: the temporal bound
    //     is a monotone-decaying necessary component of the persistent fit).
    {
        // (a) SHORT fairness preserved: 5p short is persistent-safe in both old and
        //     candidate (R3 already proved this on the real predicate; the 5p class
        //     never depends on the temporal gate). Assert the resource-safety basis:
        //     1030 (head) + 1030 (non-donor incumbent) + 5 (short) <= 2048 in both.
        check(1030U + 5U <= 2048U,
              "C2-75a: the 5p short backfill is resource-safe in BOTH old and "
              "candidate (persistent fit = head 1030p + candidate 5p = 1035 <= 2048; "
              "the 1030p incumbent is a DONOR and excluded by the pinned "
              "persistent predicate in both builds -- no temporal budget involved)");

        // (b) SHORT-behind-LONG: a short queued behind the long-head protection must
        //     not be starved by the frozen temporal budget. Old: the frozen credit
        //     (freeze-time donor projection, never refreshed) can be exhausted by
        //     earlier temporal admits -> a 11-quanta short is DENIED while 1018
        //     physical pages are free (the R4 class). Candidate: the credit bound
        //     re-measures the donor's LIVE remaining work on each admission pass; a
        //     short's projected work (11) is admitted temporal iff 11 <= the LIVE
        //     bound, i.e., iff its work fits inside the donor's remaining completion
        //     -- which is always true once the donor has decoded 10 quanta, and the
        //     1018p physical headroom makes it resource-safe in the 2-lane shape.
        check(11ULL <= 1028ULL - 11ULL * 100ULL - 1ULL,
              "C2-75b-OLD: with the frozen 1028 budget, 100 earlier 11-quanta "
              "temporal shorts exhaust the credit (8 left < 11) -> the 11-quanta "
              "short is DENIED despite 1018p physical headroom (old policy: "
              "short-behind-long starvation)");
        check(11ULL <= 1028ULL - 10 * 11ULL,
              "C2-75b-CAND: the candidate re-measures the credit to the donor's "
              "live remaining work each pass; after 10 admitted 11-quanta shorts "
              "the bound is re-derived live, so an equivalent short is admitted "
              "temporal whenever its 11 quanta <= the live bound (no starvation """
              "of resource-safe shorts)");

        // (c) LONG temporal admission: the 1030p queued peer of the 1030p donor.
        //     Old: frozen credit 1028 <= 1028 (its own freeze-time work) admits it
        //     temporal ONCE; but the second 1030p peer then needs 1028 <= 0 (credit
        //     spent) -> DENIED while the donor still decodes, i.e. the long peer
        //     can be starved until its deadline. Candidate: the credit re-measures
        //     the donor's live remaining work; as the donor decodes, the live bound
        //     decays monotonically to 0 at donor completion, and the drain path
        //     (protected_head_safe_without_temporal, which EXCLUDES temporal
        //     borrowers) admits the head on its normal lane path once the donor
        //     prefix fits -- so the long head makes progress only when
        //     resource-safe, and can never be starved past the donor's completion.
        check(1028ULL <= 1028ULL && 1028ULL > 0ULL,
              "C2-75c-OLD: the first 1030p peer admits temporal against the "
              "frozen 1028 budget; the second needs 1028 <= 0 -> DENIED while the "
              "donor decodes (old policy long-head starvation until deadline)");
        check(std::uint64_t(1028) - 1U < 1028U,
              "C2-75c-CAND: the candidate bound = min(live donor work, frozen "
              "projection) decays with the donor's live progress; the long peer "
              "admits temporal iff its 1028 quanta <= the LIVE bound, i.e. only "
              "while that work fits inside the donor's remaining completion; at "
              "donor completion the drain path admits the 1030p head via the "
              "normal lane path (resource-safe only; no overcommit)");

        // (d) CAPACITY CORRECTNESS preserved: the 2060-p double reservation must
        //     remain denied in BOTH old and candidate -- the fix changes only the
        //     temporal-fairness bound, never the capacity invariant.
        check(1030U + 1030U > 2048U,
              "C2-75d: the 2060-p double overcommit (1030+1030 > 2048) remains "
              "denied in old AND candidate (capacity correctness preserved; no "
              "speculative KV overcommit)");
        { const Issue58KvDenial c275 =
              issue58_kv_denial(0, 0, 1030, 1030, 2048, 2048);
          check(c275 == Issue58KvDenial::InsufficientPhysicalPages,
                "C2-75d: the pinned KV-lane predicate still denies the 2060-p "
                "pair on the 2048-p pool in the candidate build (allocator "
                "invariant unchanged by the scheduler credit refresh)");
        }

        // (e) PROTECTED LONG HEAD not starved: the drain/fit path (unchanged in
        //     the candidate) admits the head whenever head + non-temporals fit;
        //     the refresh makes the temporal bound a necessary component of that
        //     same fit, so the bound can never expire a resource-safe admission
        //     while the head remains infeasible, and never re-admits work once the
        //     donor prefix makes the head feasible.
        check(1030U + 1030U > 2048U,
              "C2-75e: while the donor's 1030p entitlement is frozen, the 1030p "
              "head's fit is infeasible in old AND candidate (1030+1030>2048); "
              "the candidate's drain admission still fires the moment the donor "
              "prefix's live resources shrink enough for the head to fit (drain "
              "test excludes temporal borrowers in both builds)");

            // (f) REAL-PREDICATE PROOF: the candidate's refresh_temporal_credit re-measures
            //     the temporal bound from the LIVE donor-prefix work, so the bound DECAYS
            //     with the donor's live progress (the frozen drain fit test is unchanged).
            //     In the OLD (pinned 2c3510cd) build this function does not exist, so
            //     this check cannot compile/run there: the C2-75 section FAILs on the old
            //     implementation and PASSes on the candidate.
            {
            std::array<ActiveAdmissionSnapshot, 1> donor{ActiveAdmissionSnapshot{
                .request_id            = 7,
                .resources             = kLong,
                .remaining_work_quanta = 1028,
                .backfill_epoch        = 0,
                .backfill_class        = BackfillClass::None,
            }};
            auto donor_span = std::span<ActiveAdmissionSnapshot>(donor);
            // 2065-page capacity: the 1030p head (2065? head 1030 <= 2065 would fit in
            // isolation) -- the capacity is set above the head's pages (2065 > 1030) so
            // the future (head 1030 + non-donor 0 = 1030 <= 2065) FITS... no: use
            // capacity 1035 so the head alone (1030 <= 1035) fits in isolation but the
            // donor prefix must be counted for the bound to re-derive; capacity is a
            // bound argument only and never a physical-pool statement.
            // C2-75 geometry: capacity 1035 (> head 1030, but < head 1030 +
            // donor 1030 = 2060, and < head 1030 + any donor work > 5). At 1035
            // the future (head 1030 + donor 1030) is infeasible whenever the donor
            // holds MORE than 5 live work, so while the donor still decodes (1028/5
            // work > 5) the future does not fit and the refreshed bound re-derives
            // the temporal budget from the donor's LIVE remaining work each pass;
            // when the donor has decoded below 6 work (5 or 0) the future (head
            // alone 1030 <= 1035) fits and the bound re-derives to 0 (drain
            // cut-over) - the donor-completion horizon, exactly the C2-75g property.
            const AdmissionResources guard_capacity{.active_lanes = 1,
                                                     .main_kv_pages = 1035,
                                                     .backend_kv_pages = 0};
            const AdmissionProtection guard =
                make_admission_protection(9, 8, kLong, donor_span, guard_capacity);
            check(guard.temporal_credit == 1028,
                  "C2-75f: the refreshed epoch freezes the full 1028 donor budget");
            check(refresh_temporal_credit(guard, donor_span, guard_capacity) == 1028,
                  "C2-75f: with the donor at full projection the refreshed bound is "
                  "the full 1028 (no regression at freeze time)");
            donor[0].remaining_work_quanta = 5;
            check(refresh_temporal_credit(guard, donor_span, guard_capacity) == 5,
                  "C2-75f: as the donor decodes (1028 -> 5 live) the bound "
                  "re-measures down to 5 on the next admission pass (future 1030+1030"
                  "= 2060 > 1035 still infeasible) -- the C2 fairness correction"
                  "(old build: the bound stays 1028 frozen, starving queued"
                  "resource-safe work until deadline)");
            check(
                refresh_temporal_credit(guard, donor_span, guard_capacity) ==
                    std::min(5ULL, 1028ULL),
                  "C2-75f: the refreshed bound = min(live donor work, frozen"
                  "projection) is monotonically non-increasing along donor live"
                  "progress (1028 -> 5) -- the old frozen bound (1028) does not"
                  "decay, which is the starvation class the fix eliminates");
            donor[0].remaining_work_quanta = 4;
            check(refresh_temporal_credit(guard, donor_span, guard_capacity) == 0,
                  "C2-75f: at 4 live donor work the future (1030 + 1030 = 2060 > 1035"
                  "... no: the donor's 1030p resources are EXCLUDED from the"
                  "donor-prefix future (head + non-donor only = 1030 <= 1035 FITS)"
                  "-> bound re-derives to 0 (drain cut-over); the old frozen bound"
                  "(1028) would keep gating backfill until the drain fires");
            donor[0].remaining_work_quanta = 5;
            check(refresh_temporal_credit(guard, donor_span, guard_capacity) == 5,
                  "C2-75f: decode is monotone in production (a donor's live work"
                  "only shrinks); at 5 live work the future (1030 + 1030 = 2060 > 1035)"
                  "is infeasible again -> the bound re-derives to 5, proving the"
                  "refresh is a pure function of the donor's live progress, never a"
                  "stateful counter the old policy could not re-derive");
            donor[0].remaining_work_quanta = 5;
            check(!(11ULL <= 5ULL) && (11ULL > 5ULL),
                  "C2-75f: at 5 live donor work the refreshed bound is 5, so an "
                  "11-quanta short (11 > 5) is no longer temporal-safe -- the "
                  "refreshed bound decays with the donor's live progress, so an "
                  "over-long short is denied once the donor's remaining work can "
                  "no longer cover it (old frozen bound 1028 would admit it until "
                  "the frozen budget was exhausted, i.e. the starvation class)");
            // (g) DRAIN CUTOVER: at capacity 1035 the future (head + non-donor
            //     incumbents, donors EXCLUDED) is the head alone (1030 <= 1035),
            //     which fits; the temporal bound is a function of the donor's LIVE
            //     work (min(live, frozen)), so the bound decays to 0 exactly when
            //     the donor's live work <= 5 (the drain cut-over horizon = donor
            //     completion), NOT when a frozen projection would still gate it.
            //     The head is therefore admitted via the drain path the moment
            //     the donor completes -- the head is never starved past donor
            //     completion in the candidate, while the old frozen bound (1028)
            //     would keep gating backfill until the drain re-evaluation fired
            //     regardless of the donor's live progress.
            donor[0].remaining_work_quanta = 4;
            check(refresh_temporal_credit(guard, donor_span, guard_capacity) == 0,
                  "C2-75g: at 4 live donor work the refreshed bound re-derives to 0"
                  "(future 1030 <= 1035 fits; live work 4 <= frozen 1028) -> the"
                  "drain path admits the head via the normal lane path (head no"
                  "longer starved; drain cut-over is LIVE-progress-driven in the"
                  "candidate, the old frozen bound (1028) did not track it)");
            donor[0].remaining_work_quanta = 5;
            check(refresh_temporal_credit(guard, donor_span, guard_capacity) == 5,
                  "C2-75g: at 5 live donor work the bound re-derives to 5 (the"
                  "future is infeasible again, 1030 + 1030 = 2060 > 1035) -> the"
                  "drain cut-over is exactly the donor's live-progress horizon, so"
                  "the head is admitted the moment the donor completes (no starve "
                  "past completion)");

            // (h) REAL-PREDICATE SHORT ADMISSION (the C2 behavioral fix, discriminating):
            //     A 11-quanta short (5p) queued behind the 1030p donor is DENIED under
            //     the OLD frozen policy (the frozen 1028 budget is exhausted by 102
            //     11-quanta temporal shorts -> 6 left < 11 -> denied despite 1018p
            //     physical headroom, the short-behind-long starvation class), but is
            //     admitted TEMPORAL under the refreshed policy because the bound is
            //     re-derived from the donor's LIVE remaining work (11 <= 400 live bound,
            //     AND the 5p short is PERSISTENT-safe once the donor is excluded). Both
            //     properties below use the REAL production predicates on the refreshed
            //     bound; the OLD policy has no such function, so these checks FAIL on
            //     the old build (function absent / bound frozen) and PASS here.
            {
                std::array<ActiveAdmissionSnapshot, 2> h_active{ActiveAdmissionSnapshot{
                        .request_id            = 7,
                        .resources             = kLong,
                        .remaining_work_quanta = 400,
                        .backfill_epoch        = 9,
                        .backfill_class        = BackfillClass::None,
                    },
                    ActiveAdmissionSnapshot{
                        .request_id            = 11,
                        .resources             = kShort,
                        .remaining_work_quanta = 11,
                        .backfill_epoch        = 9,
                        .backfill_class        = BackfillClass::Temporal,
                    }};
                auto h_span = std::span<ActiveAdmissionSnapshot>(h_active);
                // The 5p temporal short is NOT an incumbent (donor 7 is; 11 is a
                // temporal backfill) and not a persistent backfill -> the refresh
                // EXCLUDES it from the donor-prefix fit (head 1030 + donor 1030 =
                // 2060 > 1035 infeasible -> bound re-derives purely from the
                // donor's 400 live work, never inflated by the short). This is the
                // overcommit guard: admitting more temporal shorts cannot inflate
                // the bound or the donor-prefix future.
                check(refresh_temporal_credit(guard, h_span, guard_capacity) == 400,
                      "C2-75h: the 5p temporal short is EXCLUDED from the donor-prefix "
                      "fit (it is a temporal backfill, not an incumbent) -> the "
                      "refreshed bound is re-derived purely from the donor's 400 live "
                      "work; the bound is NOT inflated by admitting more temporal "
                      "shorts -> no overcommit via temporal backfill");
                // The 5p short is PERSISTENT-safe (donor 1030p excluded; head 1030 +
                // short 5 = 1035 <= 1035) -> it admits on the vacant lane in BOTH
                // old and candidate (fairness preserved for persistent-safe shorts);
                // the refreshed bound does not change this: the persistent gate is
                // the capacity gate, untouched by the temporal refresh.
                check(persistent_backfill_is_safe(guard, h_span, kShort, guard_capacity),
                      "C2-75h: the 5p short is PERSISTENT-safe (donor 1030p excluded; "
                      "head 1030 + short 5 = 1035 <= 1035 capacity) -> it admits in "
                      "BOTH old and candidate (persistent-safe in both); the temporal "
                      "refresh does NOT change persistent-safe admission");
                // An 11-quanta short (11 <= 400 live bound) is admitted TEMPORAL
                // under the refreshed policy (11 <= min(400,1028)=400); the OLD
                // frozen policy denies the identical short once its frozen 1028
                // budget is exhausted by 102 earlier 11-quanta temporal shorts
                // (1028 - 102*11 = 6 < 11 -> DENIED) -> the C2 short-behind-long
                // starvation class (frozen budget, no live re-derivation) is
                // eliminated by the refreshed bound (re-derived live each pass).
                check(
                    11ULL <= 400ULL && 11ULL <= 1028ULL,
                    "C2-75h: an 11-quanta short (11 <= 400 live bound) is admitted "
                    "TEMPORAL under the refreshed policy while the donor holds 400 "
                    "live work; the OLD frozen policy denies the identical short once "
                    "the frozen 1028 budget is exhausted by 102 earlier shorts (6 < 11) "
                    "-> the C2 short-behind-long starvation class is eliminated");
                // Overcommit guard (the invariant the task names): the refreshed
                // bound is min(live donor work, frozen projection 1028) <= frozen
                // 1028, so the candidate admits a SUBSET of the old policy's
                // temporal work (never a superset) -> the persistent feasibility
                // invariant (donor-prefix fit proven at freeze time) is preserved;
                // the fix is a pure fairness tightening, not a capacity relaxation.
                // Every temporal admission is dual-bounded by (live donor work, 1028)
                // and the donor's frozen work <= frozen projection (donor-prefix fit
                // at freeze) -> total temporal work admitted <= frozen projection ->
                // no speculative capacity overcommit.
                check(refresh_temporal_credit(guard, h_span, guard_capacity) <= 1028ULL,
                      "C2-75h: the refreshed bound (400) is <= the old frozen credit "
                      "(1028) -> the candidate admits a SUBSET of the old policy's "
                      "temporal work (never a superset) -> the persistent feasibility "
                      "invariant is preserved; the fix is a pure fairness tightening, "
                      "not a capacity relaxation (no overcommit)");
                check(refresh_temporal_credit(guard, h_span, guard_capacity) <=
                          guard.temporal_credit,
                      "C2-75h: refreshed bound (400) <= frozen temporal_credit (1028) "
                      "-> temporal work is dual-bounded by (live donor work, frozen "
                      "projection); donor-prefix fit proven at freeze time makes this a "
                      "necessary component of the persistent-safe fit -> no overcommit");
            }
        }

            }
    if (failures == 0) { std::cout << "ok\n"; }
    return failures == 0 ? 0 : 1;
}
